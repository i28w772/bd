// device.js — lightweight, dependency-free device/browser detection.
// Good enough for a friendly system-info card; not meant to be bulletproof.

export function detectDevice() {
  const ua = navigator.userAgent || ''
  const platform = navigator.platform || ''
  const maxTouch = navigator.maxTouchPoints || 0
  const isTouch = maxTouch > 0 || 'ontouchstart' in window

  // iPadOS 13+ reports itself as "MacIntel" — the touch-point check catches it.
  const isIPad = /iPad/.test(ua) || (platform === 'MacIntel' && maxTouch > 1)
  const isIPhone = /iPhone|iPod/.test(ua)
  const isAndroid = /Android/.test(ua)
  const isAndroidTablet = isAndroid && !/Mobile/.test(ua)
  const isWindows = /Win/.test(platform)
  const isMac = /Mac/.test(platform) && !isIPad
  const isLinux = /Linux/.test(platform) && !isAndroid

  let deviceType = 'Desktop'
  if (isIPad) deviceType = 'iPad'
  else if (isIPhone) deviceType = 'iPhone'
  else if (isAndroidTablet) deviceType = 'Android Tablet'
  else if (isAndroid) deviceType = 'Android Phone'
  else if (isTouch && Math.min(window.innerWidth, window.innerHeight) > 620) deviceType = 'Touch Tablet'

  let os = 'Unknown OS'
  if (isIPad || isIPhone) os = 'iPadOS / iOS'
  else if (isAndroid) os = 'Android'
  else if (isWindows) os = 'Windows'
  else if (isMac) os = 'macOS'
  else if (isLinux) os = 'Linux'

  let browser = 'Unknown browser'
  if (/Edg\//.test(ua)) browser = 'Edge'
  else if (/CriOS\//.test(ua)) browser = 'Chrome (iOS)'
  else if (/Chrome\//.test(ua) && !/Edg\//.test(ua)) browser = 'Chrome'
  else if (/Firefox\//.test(ua)) browser = 'Firefox'
  else if (/Safari\//.test(ua) && !/Chrome\//.test(ua)) browser = 'Safari'

  return {
    deviceType,
    os,
    browser,
    isTouch,
    width: window.innerWidth,
    height: window.innerHeight,
    pixelRatio: window.devicePixelRatio || 1,
    orientation: window.innerWidth >= window.innerHeight ? 'Landscape' : 'Portrait',
  }
}
