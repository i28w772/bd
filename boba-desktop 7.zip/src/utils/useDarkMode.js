import { useEffect, useState } from 'react'

const STORAGE_KEY = 'bobaos_theme'

function getSystemPref() {
  return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

function getInitialMode() {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY)
    if (saved === 'dark' || saved === 'light' || saved === 'system') return saved
  } catch (e) {
    // ignore
  }
  return 'system'
}

/**
 * `mode` is the user's stored preference: 'light' | 'dark' | 'system'.
 * `isDark` is the resolved boolean actually applied — when mode is
 * 'system' this tracks the OS preference live via matchMedia.
 */
export function useDarkMode() {
  const [mode, setMode] = useState(getInitialMode)
  const [systemDark, setSystemDark] = useState(getSystemPref)

  useEffect(() => {
    const mql = window.matchMedia?.('(prefers-color-scheme: dark)')
    if (!mql) return
    const handler = (e) => setSystemDark(e.matches)
    mql.addEventListener?.('change', handler)
    return () => mql.removeEventListener?.('change', handler)
  }, [])

  const isDark = mode === 'system' ? systemDark : mode === 'dark'

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark)
    try {
      window.localStorage.setItem(STORAGE_KEY, mode)
    } catch (e) {
      // ignore
    }
  }, [isDark, mode])

  // Quick toggle (title bar button) just flips explicitly between light/dark.
  const toggle = () => setMode(isDark ? 'light' : 'dark')

  return { mode, isDark, setMode, toggle }
}
