// stats.js — lightweight per-user loyalty/stat tracking, backed by
// localStorage and broadcast via a window event so widgets can live-update
// without prop-drilling through every game component.

const EVENT = 'bobaos:stats-update'
const ONE_DAY = 24 * 60 * 60 * 1000

function statsKey(user) {
  return `bobaos_stats_${user?.name || 'guest'}`
}

const DEFAULT_STATS = {
  visits: 0,
  streak: 0,
  lastVisit: null,
  pearlsCaught: 0,
  bestCatchScore: 0,
  bestMergeScore: 0,
}

export function getStats(user) {
  try {
    const raw = window.localStorage.getItem(statsKey(user))
    if (!raw) return { ...DEFAULT_STATS }
    return { ...DEFAULT_STATS, ...JSON.parse(raw) }
  } catch (e) {
    return { ...DEFAULT_STATS }
  }
}

function save(user, stats) {
  try {
    window.localStorage.setItem(statsKey(user), JSON.stringify(stats))
  } catch (e) {
    // ignore (private browsing, storage full, etc.)
  }
  window.dispatchEvent(new CustomEvent(EVENT, { detail: { user: user?.name } }))
}

/** Call once per session once a user is known. Updates visit count + streak. */
export function recordVisit(user) {
  if (!user) return
  const stats = getStats(user)
  const today = new Date().toDateString()
  if (stats.lastVisit === today) return stats

  const wasYesterday = stats.lastVisit && Date.now() - new Date(stats.lastVisit).getTime() <= ONE_DAY * 2
  const next = {
    ...stats,
    visits: stats.visits + 1,
    streak: wasYesterday ? stats.streak + 1 : 1,
    lastVisit: today,
  }
  save(user, next)
  return next
}

export function recordPearlsCaught(user, count) {
  if (!user || !count) return
  const stats = getStats(user)
  save(user, { ...stats, pearlsCaught: stats.pearlsCaught + count })
}

export function recordCatchScore(user, score) {
  if (!user) return
  const stats = getStats(user)
  if (score > stats.bestCatchScore) save(user, { ...stats, bestCatchScore: score })
}

export function recordMergeScore(user, score) {
  if (!user) return
  const stats = getStats(user)
  if (score > stats.bestMergeScore) save(user, { ...stats, bestMergeScore: score })
}

/** Wipes loyalty stats for the current user back to defaults. */
export function resetStats(user) {
  if (!user) return
  save(user, { ...DEFAULT_STATS })
}

/** Carries stats over to a new key when a user renames themselves. */
export function migrateStatsOnRename(oldUser, newUser) {
  if (!oldUser || !newUser || oldUser.name === newUser.name) return
  try {
    const oldKey = statsKey(oldUser)
    const newKey = statsKey(newUser)
    const raw = window.localStorage.getItem(oldKey)
    if (raw) {
      window.localStorage.setItem(newKey, raw)
      window.localStorage.removeItem(oldKey)
    }
  } catch (e) {
    // ignore
  }
  window.dispatchEvent(new CustomEvent(EVENT, { detail: { user: newUser.name } }))
}

export function subscribeStats(callback) {
  window.addEventListener(EVENT, callback)
  return () => window.removeEventListener(EVENT, callback)
}
