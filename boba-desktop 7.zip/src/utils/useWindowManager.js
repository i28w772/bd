import { useCallback, useEffect, useState } from 'react'

const STORAGE_KEY = 'bobaos_windows'

const DEFAULT_POSITIONS = {
  terminal: { x: 60, y: 70 },
  notes: { x: 420, y: 100 },
  ambience: { x: 240, y: 260 },
  recipes: { x: 100, y: 220 },
  converter: { x: 480, y: 320 },
}

function defaultState() {
  const state = {}
  Object.keys(DEFAULT_POSITIONS).forEach((id) => {
    state[id] = { open: false, minimized: false, maximized: false, ...DEFAULT_POSITIONS[id] }
  })
  return state
}

function clampPosition(pos) {
  const maxX = Math.max(0, window.innerWidth - 90)
  const maxY = Math.max(0, window.innerHeight - 44)
  return {
    x: Math.min(Math.max(pos.x, -20), maxX),
    y: Math.min(Math.max(pos.y, 0), maxY),
  }
}

function load() {
  const base = defaultState()
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return base
    const parsed = JSON.parse(raw)
    Object.keys(base).forEach((id) => {
      if (parsed[id]) {
        const clamped = clampPosition({
          x: Number.isFinite(parsed[id].x) ? parsed[id].x : base[id].x,
          y: Number.isFinite(parsed[id].y) ? parsed[id].y : base[id].y,
        })
        base[id] = { ...base[id], ...parsed[id], ...clamped }
      }
    })
    return base
  } catch (e) {
    return base
  }
}

export function useWindowManager() {
  const [windows, setWindows] = useState(load)
  const [zCounter, setZCounter] = useState(() => {
    const initial = load()
    return Math.max(10, ...Object.values(initial).map((w) => w.z || 0))
  })

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(windows))
    } catch (e) {
      // ignore
    }
  }, [windows])

  const focus = useCallback((id) => {
    setZCounter((c) => {
      const next = c + 1
      setWindows((w) => ({ ...w, [id]: { ...w[id], z: next } }))
      return next
    })
  }, [])

  const open = useCallback(
    (id) => {
      setWindows((w) => ({
        ...w,
        [id]: {
          ...w[id],
          open: true,
          minimized: false,
          // Dragging a small window around a phone screen is awkward —
          // default to filling the screen there instead.
          maximized: w[id].maximized || window.innerWidth <= 640,
        },
      }))
      focus(id)
    },
    [focus]
  )

  const close = useCallback((id) => {
    setWindows((w) => ({ ...w, [id]: { ...w[id], open: false, minimized: false, maximized: false } }))
  }, [])

  const minimize = useCallback((id) => {
    setWindows((w) => ({ ...w, [id]: { ...w[id], minimized: true } }))
  }, [])

  const restore = useCallback(
    (id) => {
      setWindows((w) => ({ ...w, [id]: { ...w[id], minimized: false } }))
      focus(id)
    },
    [focus]
  )

  const toggleMaximize = useCallback(
    (id) => {
      setWindows((w) => ({ ...w, [id]: { ...w[id], maximized: !w[id].maximized } }))
      focus(id)
    },
    [focus]
  )

  /** Click behavior for a dock/taskbar icon: open if closed, restore if minimized, else minimize. */
  const handleDockClick = useCallback(
    (id) => {
      setWindows((w) => {
        const cur = w[id]
        if (!cur.open) {
          return {
            ...w,
            [id]: { ...cur, open: true, minimized: false, maximized: cur.maximized || window.innerWidth <= 640 },
          }
        }
        if (cur.minimized) return { ...w, [id]: { ...cur, minimized: false } }
        return { ...w, [id]: { ...cur, minimized: true } }
      })
      focus(id)
    },
    [focus]
  )

  const updatePosition = useCallback((id, pos) => {
    const clamped = clampPosition(pos)
    setWindows((w) => ({ ...w, [id]: { ...w[id], x: clamped.x, y: clamped.y } }))
  }, [])

  return { windows, open, close, minimize, restore, toggleMaximize, handleDockClick, updatePosition, focus }
}
