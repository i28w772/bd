import { useEffect, useState } from 'react'

const STORAGE_KEY = 'bobaos_settings'

export const WIDGET_LABELS = {
  weather: 'Boba Weather',
  clock: 'Café Timer',
  hardware: 'Boba Tank Levels',
  device: 'About This Café',
  timer: 'Brew Timer',
  punchcard: 'Boba Punch Card',
  calc: 'Boba Calc',
  nearby: 'Nearby Boba & Bites',
  arcade: 'Mini Arcade',
}

const DEFAULTS = {
  volume: 0.35,
  muted: false,
  widgets: {
    weather: true,
    clock: true,
    hardware: true,
    device: true,
    timer: true,
    punchcard: true,
    calc: true,
    nearby: true,
    arcade: true,
  },
}

function load() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return DEFAULTS
    const parsed = JSON.parse(raw)
    return {
      ...DEFAULTS,
      ...parsed,
      widgets: { ...DEFAULTS.widgets, ...(parsed.widgets || {}) },
    }
  } catch (e) {
    return DEFAULTS
  }
}

export function useSettings() {
  const [settings, setSettings] = useState(load)

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))
    } catch (e) {
      // ignore
    }
  }, [settings])

  const setVolume = (v) => setSettings((s) => ({ ...s, volume: v }))

  const setMuted = (m) => setSettings((s) => ({ ...s, muted: m }))

  const toggleWidget = (key) =>
    setSettings((s) => ({ ...s, widgets: { ...s.widgets, [key]: !s.widgets[key] } }))

  const resetWidgets = () => setSettings((s) => ({ ...s, widgets: { ...DEFAULTS.widgets } }))

  return { settings, setVolume, setMuted, toggleWidget, resetWidgets }
}
