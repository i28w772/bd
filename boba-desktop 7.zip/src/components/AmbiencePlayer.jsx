import { useEffect, useRef, useState } from 'react'
import { Play, Pause } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

// Fully procedural, generative loops — no audio files. Routed through the
// same shared master gain as the rest of the app's sound effects, so the
// Settings volume slider and mute switch control this too.

const PRESETS = [
  { id: 'rain', label: 'Rainy Window', tones: [220, 329.63], cutoff: 500, wave: 'sine', noise: true, volume: 0.22 },
  { id: 'lofi', label: 'Lo-Fi Focus', tones: [196, 246.94, 293.66], cutoff: 900, wave: 'triangle', noise: false, volume: 0.16 },
  { id: 'matcha', label: 'Matcha Chill', tones: [261.63, 329.63, 392], cutoff: 700, wave: 'sine', noise: false, volume: 0.16 },
]

function startAmbience(ctx, destination, preset) {
  const master = ctx.createGain()
  master.gain.value = 0
  master.connect(destination)
  master.gain.linearRampToValueAtTime(preset.volume, ctx.currentTime + 1.2)

  const nodes = []

  preset.tones.forEach((freq, i) => {
    const osc = ctx.createOscillator()
    osc.type = preset.wave || 'sine'
    osc.frequency.value = freq

    const gain = ctx.createGain()
    gain.gain.value = 0.2

    const filter = ctx.createBiquadFilter()
    filter.type = 'lowpass'
    filter.frequency.value = preset.cutoff || 800

    osc.connect(gain)
    gain.connect(filter)
    filter.connect(master)
    osc.start()
    nodes.push(osc)

    // Slow LFO on the filter cutoff so it breathes instead of droning flatly.
    const lfo = ctx.createOscillator()
    lfo.frequency.value = 0.04 + i * 0.015
    const lfoGain = ctx.createGain()
    lfoGain.gain.value = (preset.cutoff || 800) * 0.25
    lfo.connect(lfoGain)
    lfoGain.connect(filter.frequency)
    lfo.start()
    nodes.push(lfo)
  })

  if (preset.noise) {
    const bufferSize = 2 * ctx.sampleRate
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate)
    const data = buffer.getChannelData(0)
    for (let i = 0; i < bufferSize; i++) data[i] = (Math.random() * 2 - 1) * 0.3
    const noise = ctx.createBufferSource()
    noise.buffer = buffer
    noise.loop = true

    const noiseFilter = ctx.createBiquadFilter()
    noiseFilter.type = 'lowpass'
    noiseFilter.frequency.value = 1200

    const noiseGain = ctx.createGain()
    noiseGain.gain.value = 0.15

    noise.connect(noiseFilter)
    noiseFilter.connect(noiseGain)
    noiseGain.connect(master)
    noise.start()
    nodes.push(noise)
  }

  return {
    stop: () => {
      const now = ctx.currentTime
      master.gain.cancelScheduledValues(now)
      master.gain.setValueAtTime(master.gain.value, now)
      master.gain.linearRampToValueAtTime(0, now + 0.7)
      setTimeout(() => {
        nodes.forEach((n) => {
          try {
            n.stop()
          } catch (e) {
            // already stopped
          }
        })
        master.disconnect()
      }, 800)
    },
  }
}

export default function AmbiencePlayer() {
  const [presetId, setPresetId] = useState('rain')
  const [playing, setPlaying] = useState(false)
  const engineRef = useRef(null)

  const preset = PRESETS.find((p) => p.id === presetId) || PRESETS[0]

  const stopEngine = () => {
    engineRef.current?.stop()
    engineRef.current = null
  }

  const play = () => {
    soundManager.click()
    const ctx = soundManager.getContext()
    stopEngine()
    engineRef.current = startAmbience(ctx, soundManager.getMasterGain(), preset)
    setPlaying(true)
  }

  const pause = () => {
    soundManager.click()
    stopEngine()
    setPlaying(false)
  }

  const selectPreset = (id) => {
    soundManager.hover()
    setPresetId(id)
    if (playing) {
      const ctx = soundManager.getContext()
      stopEngine()
      engineRef.current = startAmbience(ctx, soundManager.getMasterGain(), PRESETS.find((p) => p.id === id))
    }
  }

  useEffect(() => () => stopEngine(), [])

  return (
    <div className="h-full flex flex-col p-3">
      <div className="flex flex-col gap-1.5 mb-4">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            onClick={() => selectPreset(p.id)}
            className={`text-left px-3 py-2 rounded-xl text-xs font-semibold transition-colors touch-manipulation ${
              presetId === p.id ? 'bg-matcha text-white shadow-soft' : 'bg-white/40 text-pearl/70 hover:bg-white/60'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      <button
        onClick={playing ? pause : play}
        className="mt-auto flex items-center justify-center gap-2 py-2.5 rounded-full bg-taro text-white text-sm font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
      >
        {playing ? <Pause size={15} /> : <Play size={15} />}
        {playing ? 'Pause ambience' : 'Play ambience'}
      </button>
      <p className="text-[10px] text-pearl/40 text-center mt-2">
        Generative loops synthesized live — shares the app's volume & mute controls.
      </p>
    </div>
  )
}
