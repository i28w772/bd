import { useEffect, useRef, useState } from 'react'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { MapPin, RefreshCw, Navigation } from 'lucide-react'
import LoadingSpinner from './LoadingSpinner.jsx'
import soundManager from '../utils/soundManager.js'

// Free, key-free stack: OpenStreetMap's Overpass API for place data, and
// OSM raster tiles for the map itself via Leaflet. Same zero-config spirit
// as the weather widget. Note: the public OSM tile server asks that heavy
// production traffic use a paid/self-hosted tile provider instead — fine
// for personal/dev use, worth swapping (MapTiler, Stadia Maps, etc.) if
// this app gets serious traffic. See README.

function toRad(d) {
  return (d * Math.PI) / 180
}

function distanceMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000
  const dLat = toRad(lat2 - lat1)
  const dLon = toRad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

function formatDistance(m) {
  return m < 1000 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`
}

function isBobaSpot(tags = {}) {
  const blob = `${tags.name || ''} ${tags.cuisine || ''} ${tags.shop || ''}`.toLowerCase()
  return /bubble.?tea|boba|\btea\b/.test(blob)
}

const emojiIcon = (emoji) =>
  L.divIcon({
    html: `<div style="font-size:22px;line-height:1;transform:translate(-50%,-90%);filter:drop-shadow(0 1px 1px rgba(0,0,0,.35))">${emoji}</div>`,
    className: '',
    iconSize: [0, 0],
  })

export default function NearbyBoba() {
  const [status, setStatus] = useState('idle') // idle | locating | loading | ready | error
  const [errorMsg, setErrorMsg] = useState('')
  const [places, setPlaces] = useState([])
  const [coords, setCoords] = useState(null)

  const mapContainerRef = useRef(null)
  const mapRef = useRef(null)
  const markersRef = useRef([])

  const load = () => {
    // The map container div only exists while status === 'ready', so it
    // gets unmounted on every refresh. Without this, mapRef would still
    // point at a Leaflet instance bound to a now-detached DOM node.
    if (mapRef.current) {
      mapRef.current.remove()
      mapRef.current = null
    }
    markersRef.current = []

    if (!navigator.geolocation) {
      setStatus('error')
      setErrorMsg('Geolocation is not supported in this browser.')
      return
    }
    soundManager.click()
    setStatus('locating')
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords
        setCoords({ lat: latitude, lon: longitude })
        setStatus('loading')
        try {
          const query = `[out:json][timeout:15];(node["amenity"="cafe"](around:1500,${latitude},${longitude});node["shop"="tea"](around:1500,${latitude},${longitude});node["cuisine"~"bubble_tea"](around:1500,${latitude},${longitude});node["amenity"="restaurant"](around:1500,${latitude},${longitude}););out center 40;`
          const res = await fetch('https://overpass-api.de/api/interpreter', {
            method: 'POST',
            body: query,
          })
          if (!res.ok) throw new Error('Overpass request failed')
          const json = await res.json()
          const named = (json.elements || [])
            .filter((el) => el.tags?.name)
            .map((el) => {
              const lat = el.lat ?? el.center?.lat
              const lon = el.lon ?? el.center?.lon
              return {
                id: el.id,
                name: el.tags.name,
                lat,
                lon,
                boba: isBobaSpot(el.tags),
                distance: distanceMeters(latitude, longitude, lat, lon),
              }
            })
            .filter((p) => Number.isFinite(p.lat) && Number.isFinite(p.lon))
            .sort((a, b) => a.distance - b.distance)
            .slice(0, 12)
          setPlaces(named)
          setStatus('ready')
        } catch (e) {
          setStatus('error')
          setErrorMsg("Couldn't reach the map data service — try again in a moment.")
        }
      },
      () => {
        setStatus('error')
        setErrorMsg('Location access was denied — enable it to find what’s nearby.')
      },
      { timeout: 8000 }
    )
  }

  useEffect(() => {
    load()
    return () => {
      mapRef.current?.remove()
      mapRef.current = null
    }
  }, [])

  // Initialize / update the Leaflet map once results are ready.
  useEffect(() => {
    if (status !== 'ready' || !coords || !mapContainerRef.current) return

    if (!mapRef.current) {
      mapRef.current = L.map(mapContainerRef.current, { zoomControl: false }).setView(
        [coords.lat, coords.lon],
        15
      )
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 19,
      }).addTo(mapRef.current)
      L.control.zoom({ position: 'bottomright' }).addTo(mapRef.current)
    } else {
      mapRef.current.setView([coords.lat, coords.lon], 15)
    }

    markersRef.current.forEach((m) => m.remove())
    markersRef.current = []

    const you = L.marker([coords.lat, coords.lon], { icon: emojiIcon('📍') }).addTo(mapRef.current)
    markersRef.current.push(you)

    places.forEach((p) => {
      const marker = L.marker([p.lat, p.lon], { icon: emojiIcon(p.boba ? '🧋' : '🍽️') })
        .addTo(mapRef.current)
        .bindPopup(`<strong>${p.name}</strong><br/>${formatDistance(p.distance)} away`)
      markersRef.current.push(marker)
    })

    const t = setTimeout(() => mapRef.current?.invalidateSize(), 150)
    return () => clearTimeout(t)
  }, [status, coords, places])

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5">
          <MapPin size={14} className="text-taro-dark" /> Nearby Boba & Bites
        </h3>
        <button
          onClick={load}
          className="p-1.5 rounded-full hover:bg-white/50 text-pearl/60 transition-colors touch-manipulation"
          aria-label="Refresh nearby places"
        >
          <RefreshCw size={14} className={status === 'locating' || status === 'loading' ? 'animate-spin' : ''} />
        </button>
      </div>

      {(status === 'idle' || status === 'locating' || status === 'loading') && (
        <div className="flex-1 flex items-center justify-center">
          <LoadingSpinner size={40} label={status === 'locating' ? 'Finding you…' : 'Scouting the block…'} />
        </div>
      )}

      {status === 'error' && (
        <div className="flex-1 flex flex-col items-center justify-center gap-2 text-center px-2">
          <p className="text-sm text-pearl/60">{errorMsg}</p>
          <button
            onClick={load}
            className="px-3 py-1.5 rounded-full bg-matcha text-white text-xs font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
          >
            Try again
          </button>
        </div>
      )}

      {status === 'ready' && (
        <div className="flex-1 flex flex-col sm:flex-row gap-3 min-h-0">
          <div
            ref={mapContainerRef}
            className="w-full sm:w-1/2 h-40 sm:h-full rounded-xl overflow-hidden border border-white/50 shrink-0"
          />
          <div className="flex-1 overflow-y-auto min-h-0 pr-1">
            {places.length === 0 && (
              <p className="text-xs text-pearl/50 text-center py-6">Nothing nearby turned up — try refreshing.</p>
            )}
            <ul className="space-y-1.5">
              {places.map((p) => (
                <li key={p.id}>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lon}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-white/50 transition-colors touch-manipulation"
                  >
                    <span className="text-base shrink-0">{p.boba ? '🧋' : '🍽️'}</span>
                    <span className="flex-1 min-w-0 text-xs text-pearl truncate">{p.name}</span>
                    <span className="text-[10px] text-pearl/50 shrink-0 flex items-center gap-0.5">
                      <Navigation size={10} />
                      {formatDistance(p.distance)}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <p className="text-[10px] text-pearl/40 text-center mt-2">Map data © OpenStreetMap contributors</p>
    </div>
  )
}
