import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { RotateCcw, Timer as TimerIcon } from 'lucide-react'
import soundManager from '../../utils/soundManager.js'

const BOARD_SIZE = 300
const EMOJIS = ['🧋', '🍵', '🧡', '🟣', '🥭', '🍈', '✨', '🟤']

function shuffledDeck() {
  const deck = [...EMOJIS, ...EMOJIS].map((emoji, i) => ({ id: `${emoji}-${i}`, emoji }))
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[deck[i], deck[j]] = [deck[j], deck[i]]
  }
  return deck.map((card, i) => ({ ...card, index: i, flipped: false, matched: false }))
}

function format(seconds) {
  const m = Math.floor(seconds / 60)
    .toString()
    .padStart(2, '0')
  const s = Math.floor(seconds % 60)
    .toString()
    .padStart(2, '0')
  return `${m}:${s}`
}

export default function MemoryMatch({ maxWidth }) {
  const scale = Math.max(0.6, Math.min(1, (maxWidth || BOARD_SIZE) / BOARD_SIZE))
  const [cards, setCards] = useState(() => shuffledDeck())
  const [flippedIdx, setFlippedIdx] = useState([])
  const [moves, setMoves] = useState(0)
  const [seconds, setSeconds] = useState(0)
  const [running, setRunning] = useState(false)
  const [locked, setLocked] = useState(false)

  const matches = cards.filter((c) => c.matched).length / 2
  const won = matches === EMOJIS.length

  const reset = () => {
    soundManager.click()
    setCards(shuffledDeck())
    setFlippedIdx([])
    setMoves(0)
    setSeconds(0)
    setRunning(true)
    setLocked(false)
  }

  useEffect(() => {
    if (!running || won) return
    const id = setInterval(() => setSeconds((s) => s + 1), 1000)
    return () => clearInterval(id)
  }, [running, won])

  useEffect(() => {
    if (won && running) {
      setRunning(false)
      soundManager.success()
    }
  }, [won, running])

  const flip = (index) => {
    if (locked) return
    const card = cards[index]
    if (card.flipped || card.matched) return

    if (!running && seconds === 0 && moves === 0) setRunning(true)
    soundManager.hover()

    const nextCards = cards.map((c, i) => (i === index ? { ...c, flipped: true } : c))
    setCards(nextCards)
    const nextFlipped = [...flippedIdx, index]
    setFlippedIdx(nextFlipped)

    if (nextFlipped.length === 2) {
      setLocked(true)
      setMoves((m) => m + 1)
      const [a, b] = nextFlipped
      const isMatch = nextCards[a].emoji === nextCards[b].emoji
      setTimeout(() => {
        setCards((cur) =>
          cur.map((c, i) => {
            if (i !== a && i !== b) return c
            return isMatch ? { ...c, matched: true } : { ...c, flipped: false }
          })
        )
        setFlippedIdx([])
        setLocked(false)
        soundManager[isMatch ? 'success' : 'hover']()
      }, 650)
    }
  }

  return (
    <div className="flex flex-col items-center">
      <div className="flex items-center justify-between w-full max-w-[300px] mb-2 text-xs font-mono text-pearl/70">
        <span>Moves: {moves}</span>
        <span className="flex items-center gap-1">
          <TimerIcon size={11} /> {format(seconds)}
        </span>
        <button
          onClick={reset}
          className="flex items-center gap-1 px-2 py-1 rounded-full bg-white/50 hover:bg-white/70 transition touch-manipulation"
        >
          <RotateCcw size={12} /> Reset
        </button>
      </div>

      <div className="relative mx-auto" style={{ width: BOARD_SIZE * scale, height: BOARD_SIZE * scale }}>
        <div
          className="grid grid-cols-4 grid-rows-4 gap-2 rounded-2xl border-2 border-milk-dark bg-milk/50 p-2"
          style={{ width: BOARD_SIZE, height: BOARD_SIZE, transform: `scale(${scale})`, transformOrigin: 'top left' }}
        >
          {cards.map((card, i) => (
            <button
              key={card.id}
              onClick={() => flip(i)}
              className="relative rounded-lg touch-manipulation"
              style={{ perspective: 300 }}
              disabled={card.matched}
            >
              <motion.div
                className="absolute inset-0 rounded-lg flex items-center justify-center text-lg"
                animate={{ rotateY: card.flipped || card.matched ? 180 : 0 }}
                transition={{ duration: 0.35 }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                <div
                  className="absolute inset-0 rounded-lg bg-taro/30 flex items-center justify-center text-taro-dark text-sm"
                  style={{ backfaceVisibility: 'hidden' }}
                >
                  🧋
                </div>
                <div
                  className={`absolute inset-0 rounded-lg flex items-center justify-center ${
                    card.matched ? 'bg-matcha/30' : 'bg-cream'
                  }`}
                  style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}
                >
                  {card.emoji}
                </div>
              </motion.div>
            </button>
          ))}
        </div>

        {won && (
          <div
            className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-cream/85 backdrop-blur-sm rounded-2xl"
            style={{ width: BOARD_SIZE * scale, height: BOARD_SIZE * scale }}
          >
            <p className="font-display text-pearl font-semibold text-sm text-center px-4">
              Matched it all in {moves} moves, {format(seconds)}! 🧋
            </p>
            <button
              onClick={reset}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-matcha text-white text-sm font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
            >
              <RotateCcw size={14} /> Play again
            </button>
          </div>
        )}
      </div>
      <p className="text-[11px] text-pearl/50 mt-2 text-center px-4">Flip two cards, match the flavors</p>
    </div>
  )
}
