import { useEffect, useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

export default function CommandPalette({ open, onClose, actions }) {
  const [query, setQuery] = useState('')
  const [activeIndex, setActiveIndex] = useState(0)
  const inputRef = useRef(null)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return actions
    return actions.filter(
      (a) => a.label.toLowerCase().includes(q) || a.keywords?.some((k) => k.toLowerCase().includes(q))
    )
  }, [query, actions])

  useEffect(() => {
    if (open) {
      setQuery('')
      setActiveIndex(0)
      const t = setTimeout(() => inputRef.current?.focus(), 30)
      return () => clearTimeout(t)
    }
  }, [open])

  useEffect(() => setActiveIndex(0), [query])

  const run = (action) => {
    if (!action) return
    soundManager.click()
    onClose()
    action.onRun()
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Escape') {
      onClose()
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setActiveIndex((i) => Math.min(i + 1, filtered.length - 1))
      return
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      setActiveIndex((i) => Math.max(i - 1, 0))
      return
    }
    if (e.key === 'Enter') {
      e.preventDefault()
      run(filtered[activeIndex])
    }
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[14vh] px-4 bg-pearl/30 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: -12, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.97 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md glass rounded-2xl shadow-soft glow-border overflow-hidden"
          >
            <div className="flex items-center gap-2 px-4 py-3 border-b border-white/40">
              <Search size={16} className="text-pearl/50 shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a command…"
                className="flex-1 bg-transparent outline-none text-base text-pearl placeholder:text-pearl/40"
              />
              <kbd className="hidden sm:inline text-[10px] px-1.5 py-0.5 rounded bg-white/50 text-pearl/50">Esc</kbd>
            </div>
            <div className="max-h-72 overflow-y-auto py-1.5">
              {filtered.length === 0 && <p className="text-center text-xs text-pearl/40 py-6">No matching commands</p>}
              {filtered.map((action, i) => {
                const Icon = action.icon
                return (
                  <button
                    key={action.id}
                    onMouseEnter={() => setActiveIndex(i)}
                    onClick={() => run(action)}
                    className={`w-full flex items-center gap-2.5 px-4 py-2.5 text-left text-sm transition-colors touch-manipulation ${
                      i === activeIndex ? 'bg-matcha/20 text-pearl' : 'text-pearl/75 hover:bg-white/40'
                    }`}
                  >
                    {Icon && <Icon size={15} className="text-taro-dark shrink-0" />}
                    <span className="flex-1">{action.label}</span>
                    {action.shortcut && <span className="text-[10px] text-pearl/40">{action.shortcut}</span>}
                  </button>
                )
              })}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
