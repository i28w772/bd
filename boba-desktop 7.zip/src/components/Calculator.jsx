import { useEffect, useState } from 'react'
import { Delete } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

function compute(a, b, op) {
  switch (op) {
    case '+':
      return a + b
    case '−':
      return a - b
    case '×':
      return a * b
    case '÷':
      return b === 0 ? NaN : a / b
    default:
      return b
  }
}

function formatDisplay(value) {
  if (Number.isNaN(value)) return 'Error'
  if (!Number.isFinite(value)) return 'Error'
  const str = String(value)
  return str.length > 11 ? Number(value.toPrecision(8)).toExponential(4) : str
}

export default function Calculator() {
  const [display, setDisplay] = useState('0')
  const [prev, setPrev] = useState(null)
  const [operator, setOperator] = useState(null)
  const [waiting, setWaiting] = useState(false)

  const inputDigit = (d) => {
    soundManager.hover()
    setDisplay((cur) => (waiting || cur === '0' || cur === 'Error' ? String(d) : cur + d))
    setWaiting(false)
  }

  const inputDecimal = () => {
    soundManager.hover()
    setDisplay((cur) => {
      if (waiting || cur === 'Error') return '0.'
      return cur.includes('.') ? cur : `${cur}.`
    })
    setWaiting(false)
  }

  const clearAll = () => {
    soundManager.click()
    setDisplay('0')
    setPrev(null)
    setOperator(null)
    setWaiting(false)
  }

  const backspace = () => {
    soundManager.hover()
    setDisplay((cur) => (cur.length > 1 && cur !== 'Error' ? cur.slice(0, -1) : '0'))
  }

  const toggleSign = () => {
    soundManager.hover()
    setDisplay((cur) => (cur === 'Error' ? '0' : String(parseFloat(cur) * -1)))
  }

  const percent = () => {
    soundManager.hover()
    setDisplay((cur) => (cur === 'Error' ? '0' : String(parseFloat(cur) / 100)))
  }

  const performOperator = (nextOp) => {
    soundManager.click()
    const inputValue = parseFloat(display)
    if (prev != null && operator && !waiting) {
      setDisplay(formatDisplay(compute(prev, inputValue, operator)))
      setPrev(compute(prev, inputValue, operator))
    } else {
      setPrev(inputValue)
    }
    setOperator(nextOp)
    setWaiting(true)
  }

  const equals = () => {
    if (operator == null || prev == null) return
    soundManager.success()
    const inputValue = parseFloat(display)
    const result = compute(prev, inputValue, operator)
    setDisplay(formatDisplay(result))
    setPrev(null)
    setOperator(null)
    setWaiting(true)
  }

  // Re-registers each render so handlers always see current state — cheap
  // for a calculator, and avoids stale-closure bugs from a one-time listener.
  useEffect(() => {
    const onKeyDown = (e) => {
      if (['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)) return
      if (e.key >= '0' && e.key <= '9') {
        inputDigit(e.key)
        return
      }
      if (e.key === '.') {
        inputDecimal()
        return
      }
      if (e.key === '+') {
        performOperator('+')
        return
      }
      if (e.key === '-') {
        performOperator('−')
        return
      }
      if (e.key === '*') {
        performOperator('×')
        return
      }
      if (e.key === '/') {
        e.preventDefault()
        performOperator('÷')
        return
      }
      if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault()
        equals()
        return
      }
      if (e.key === 'Backspace') {
        backspace()
        return
      }
      if (e.key === 'Escape') {
        clearAll()
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  })

  const Btn = ({ onClick, className = '', children, wide }) => (
    <button
      onClick={onClick}
      className={`rounded-xl font-semibold text-sm transition-colors active:scale-95 touch-manipulation ${
        wide ? 'col-span-2' : ''
      } ${className}`}
    >
      {children}
    </button>
  )

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl mb-3">🧋 Boba Calc</h3>

      <div className="flex items-center justify-end gap-2 bg-milk/50 rounded-xl px-3 py-2.5 mb-3">
        <span className="font-mono text-2xl text-pearl truncate">{display}</span>
      </div>

      <div className="grid grid-cols-4 gap-2 flex-1">
        <Btn onClick={clearAll} className="bg-white/50 hover:bg-white/70 text-pearl/70">
          C
        </Btn>
        <Btn onClick={toggleSign} className="bg-white/50 hover:bg-white/70 text-pearl/70">
          ±
        </Btn>
        <Btn onClick={percent} className="bg-white/50 hover:bg-white/70 text-pearl/70">
          %
        </Btn>
        <Btn onClick={() => performOperator('÷')} className="bg-taro/25 hover:bg-taro/40 text-taro-dark">
          ÷
        </Btn>

        <Btn onClick={() => inputDigit(7)} className="bg-white/40 hover:bg-white/60 text-pearl">
          7
        </Btn>
        <Btn onClick={() => inputDigit(8)} className="bg-white/40 hover:bg-white/60 text-pearl">
          8
        </Btn>
        <Btn onClick={() => inputDigit(9)} className="bg-white/40 hover:bg-white/60 text-pearl">
          9
        </Btn>
        <Btn onClick={() => performOperator('×')} className="bg-taro/25 hover:bg-taro/40 text-taro-dark">
          ×
        </Btn>

        <Btn onClick={() => inputDigit(4)} className="bg-white/40 hover:bg-white/60 text-pearl">
          4
        </Btn>
        <Btn onClick={() => inputDigit(5)} className="bg-white/40 hover:bg-white/60 text-pearl">
          5
        </Btn>
        <Btn onClick={() => inputDigit(6)} className="bg-white/40 hover:bg-white/60 text-pearl">
          6
        </Btn>
        <Btn onClick={() => performOperator('−')} className="bg-taro/25 hover:bg-taro/40 text-taro-dark">
          −
        </Btn>

        <Btn onClick={() => inputDigit(1)} className="bg-white/40 hover:bg-white/60 text-pearl">
          1
        </Btn>
        <Btn onClick={() => inputDigit(2)} className="bg-white/40 hover:bg-white/60 text-pearl">
          2
        </Btn>
        <Btn onClick={() => inputDigit(3)} className="bg-white/40 hover:bg-white/60 text-pearl">
          3
        </Btn>
        <Btn onClick={() => performOperator('+')} className="bg-taro/25 hover:bg-taro/40 text-taro-dark">
          +
        </Btn>

        <Btn onClick={() => inputDigit(0)} wide className="bg-white/40 hover:bg-white/60 text-pearl">
          0
        </Btn>
        <Btn onClick={inputDecimal} className="bg-white/40 hover:bg-white/60 text-pearl">
          .
        </Btn>
        <Btn onClick={equals} className="bg-matcha hover:brightness-105 text-white">
          =
        </Btn>
      </div>

      <button
        onClick={backspace}
        aria-label="Backspace"
        className="mt-2 self-end p-1.5 rounded-full hover:bg-white/50 text-pearl/50 transition-colors touch-manipulation"
      >
        <Delete size={14} />
      </button>
    </div>
  )
}
