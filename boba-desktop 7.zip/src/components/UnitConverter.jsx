import { useMemo, useState } from 'react'
import soundManager from '../utils/soundManager.js'

const CATEGORIES = {
  length: { label: 'Length', units: { m: 1, km: 1000, cm: 0.01, mi: 1609.34, ft: 0.3048, in: 0.0254 } },
  weight: { label: 'Weight', units: { kg: 1, g: 0.001, lb: 0.453592, oz: 0.0283495 } },
  volume: { label: 'Volume', units: { l: 1, ml: 0.001, gal: 3.78541, cup: 0.236588, floz: 0.0295735 } },
  temp: { label: 'Temp', special: true, units: { C: 'C', F: 'F', K: 'K' } },
}

function convertTemp(value, from, to) {
  if (from === to) return value
  // normalize to Celsius first
  let c = value
  if (from === 'F') c = ((value - 32) * 5) / 9
  if (from === 'K') c = value - 273.15
  if (to === 'C') return c
  if (to === 'F') return (c * 9) / 5 + 32
  if (to === 'K') return c + 273.15
  return value
}

function formatResult(n) {
  if (!Number.isFinite(n)) return '—'
  const rounded = Math.round(n * 10000) / 10000
  return String(rounded)
}

// Defined at module scope (not inside UnitConverter) — previously this was
// redeclared on every render, which meant React treated it as a *new*
// component type each time and remounted the <select> on every keystroke,
// breaking selection. Fixed by hoisting it out and passing options as a prop.
function UnitSelect({ selected, onChange, options }) {
  return (
    <select
      value={selected}
      onChange={(e) => {
        soundManager.hover()
        onChange(e.target.value)
      }}
      className="px-2 py-1.5 rounded-lg bg-white/60 border border-white/60 text-xs text-pearl outline-none focus:ring-2 focus:ring-matcha"
    >
      {options.map((u) => (
        <option key={u} value={u}>
          {u}
        </option>
      ))}
    </select>
  )
}

export default function UnitConverter() {
  const [category, setCategory] = useState('length')
  const [value, setValue] = useState('1')
  const cat = CATEGORIES[category]
  const unitKeys = Object.keys(cat.units)
  const [fromUnit, setFromUnit] = useState(unitKeys[0])
  const [toUnit, setToUnit] = useState(unitKeys[1])

  const changeCategory = (id) => {
    soundManager.hover()
    setCategory(id)
    const keys = Object.keys(CATEGORIES[id].units)
    setFromUnit(keys[0])
    setToUnit(keys[1])
  }

  const result = useMemo(() => {
    const n = parseFloat(value)
    if (Number.isNaN(n)) return '—'
    if (cat.special) return formatResult(convertTemp(n, fromUnit, toUnit))
    const meters = n * cat.units[fromUnit]
    return formatResult(meters / cat.units[toUnit])
  }, [value, fromUnit, toUnit, cat])

  return (
    <div className="h-full flex flex-col p-3">
      <div className="flex gap-1 mb-3">
        {Object.entries(CATEGORIES).map(([id, c]) => (
          <button
            key={id}
            onClick={() => changeCategory(id)}
            className={`flex-1 py-1.5 rounded-full text-[11px] font-semibold transition-colors touch-manipulation ${
              category === id ? 'bg-matcha text-white shadow-soft' : 'bg-white/40 text-pearl/60 hover:bg-white/60'
            }`}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col justify-center gap-3">
        <div className="flex items-center gap-2">
          <input
            type="number"
            inputMode="decimal"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="flex-1 min-w-0 px-3 py-2 rounded-full bg-white/60 border border-white/60 text-base text-pearl outline-none focus:ring-2 focus:ring-matcha"
          />
          <UnitSelect selected={fromUnit} onChange={setFromUnit} options={unitKeys} />
        </div>

        <div className="flex justify-center text-pearl/40 text-xs">↓</div>

        <div className="flex items-center gap-2">
          <div className="flex-1 min-w-0 px-3 py-2 rounded-full bg-milk/60 text-sm font-semibold text-pearl truncate">
            {result}
          </div>
          <UnitSelect selected={toUnit} onChange={setToUnit} options={unitKeys} />
        </div>
      </div>
    </div>
  )
}
