import { useEffect, useRef, useState } from 'react'
import { Play, Pause, RotateCcw, Timer } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

const PRESETS = [
  { id: 'quick', label: 'Quick Steep', minutes: 5 },
  { id: 'focus', label: 'Focus Brew', minutes: 25 },
  { id: 'deep', label: 'Deep Steep', minutes: 45 },
]

function format(seconds) {
  const m = Math.floor(seconds / 60)
    .toString()
    .padStart(2, '0')
  const s = Math.floor(seconds % 60)
    .toString()
    .padStart(2, '0')
  return `${m}:${s}`
}

function notify(message) {
  if (typeof Notification === 'undefined') return
  if (Notification.permission === 'granted') {
    try {
      new Notification('BobaOS', { body: message, icon: './icons/icon-192.png' })
    } catch (e) {
      // ignore — some browsers restrict Notification() outside a service worker
    }
  }
}

export default function BrewTimer() {
  const [presetId, setPresetId] = useState('focus')
  const preset = PRESETS.find((p) => p.id === presetId) || PRESETS[1]
  const [secondsLeft, setSecondsLeft] = useState(preset.minutes * 60)
  const [running, setRunning] = useState(false)
  const intervalRef = useRef(null)

  useEffect(() => {
    if (!running) setSecondsLeft(preset.minutes * 60)
  }, [presetId]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!running) return
    intervalRef.current = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(intervalRef.current)
          setRunning(false)
          soundManager.success()
          notify(`Your ${preset.label.toLowerCase()} is ready! 🧋`)
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(intervalRef.current)
  }, [running]) // eslint-disable-line react-hooks/exhaustive-deps

  const toggle = () => {
    soundManager.click()
    if (!running && typeof Notification !== 'undefined' && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {})
    }
    if (secondsLeft === 0) setSecondsLeft(preset.minutes * 60)
    setRunning((r) => !r)
  }

  const reset = () => {
    soundManager.hover()
    setRunning(false)
    setSecondsLeft(preset.minutes * 60)
  }

  const total = preset.minutes * 60
  const progress = total > 0 ? ((total - secondsLeft) / total) * 100 : 0

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5 mb-3">
        <Timer size={14} className="text-taro-dark" /> Brew Timer
      </h3>

      <div className="flex gap-1.5 mb-4">
        {PRESETS.map((p) => (
          <button
            key={p.id}
            onClick={() => {
              soundManager.hover()
              setRunning(false)
              setPresetId(p.id)
            }}
            className={`flex-1 py-1.5 rounded-full text-[11px] font-semibold transition-colors touch-manipulation ${
              presetId === p.id ? 'bg-matcha text-white shadow-soft' : 'bg-white/40 text-pearl/60 hover:bg-white/60'
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center gap-3">
        <span className="font-mono text-3xl font-semibold text-pearl tabular-nums">{format(secondsLeft)}</span>

        <div className="w-full h-2 rounded-full bg-milk/60 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-matcha to-taro transition-[width] duration-1000 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="flex items-center gap-2 mt-1">
          <button
            onClick={toggle}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-matcha text-white text-xs font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
          >
            {running ? <Pause size={13} /> : <Play size={13} />}
            {running ? 'Pause' : secondsLeft === total ? 'Start' : 'Resume'}
          </button>
          <button
            onClick={reset}
            aria-label="Reset timer"
            className="p-1.5 rounded-full hover:bg-white/50 text-pearl/60 transition-colors touch-manipulation"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </div>
    </div>
  )
}
