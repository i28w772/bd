import { useEffect, useState } from 'react'
import { Flame, Droplet, Trophy } from 'lucide-react'
import { getStats, subscribeStats } from '../utils/stats.js'

export default function PunchCard({ user }) {
  const [stats, setStats] = useState(() => getStats(user))

  useEffect(() => {
    setStats(getStats(user))
    const unsubscribe = subscribeStats(() => setStats(getStats(user)))
    return unsubscribe
  }, [user])

  const stamps = Array.from({ length: 7 }, (_, i) => i < Math.min(stats.streak, 7))

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5 mb-3">
        <Trophy size={14} className="text-taro-dark" /> Boba Punch Card
      </h3>

      <div className="flex items-center gap-1.5 mb-3">
        {stamps.map((filled, i) => (
          <span
            key={i}
            className={`h-5 w-5 rounded-full border flex items-center justify-center text-[10px] ${
              filled ? 'bg-matcha border-matcha text-white' : 'border-pearl/25 text-transparent'
            }`}
          >
            🧋
          </span>
        ))}
      </div>
      <p className="text-[11px] text-pearl/60 flex items-center gap-1 mb-4">
        <Flame size={12} className="text-taro-dark" />
        {stats.streak > 0 ? `${stats.streak}-day streak, ${stats.visits} visits total` : 'Come back tomorrow to start a streak'}
      </p>

      <div className="mt-auto grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-milk/50 py-2">
          <p className="font-display text-base font-semibold text-pearl leading-none flex items-center justify-center gap-1">
            <Droplet size={12} className="text-taro-dark" />
            {stats.pearlsCaught}
          </p>
          <p className="text-[9px] text-pearl/50 mt-1">pearls caught</p>
        </div>
        <div className="rounded-xl bg-milk/50 py-2">
          <p className="font-display text-base font-semibold text-pearl leading-none">{stats.bestCatchScore}</p>
          <p className="text-[9px] text-pearl/50 mt-1">best catch</p>
        </div>
        <div className="rounded-xl bg-milk/50 py-2">
          <p className="font-display text-base font-semibold text-pearl leading-none">{stats.bestMergeScore}</p>
          <p className="text-[9px] text-pearl/50 mt-1">best merge</p>
        </div>
      </div>
    </div>
  )
}
