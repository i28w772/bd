import { useEffect, useState } from 'react'
import { Star } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

const RECIPES = [
  {
    id: 'classic-milk',
    name: 'Classic Milk Tea',
    emoji: '🧋',
    tagline: 'The one that started it all',
    ingredients: ['Black tea', 'Milk', 'Brown sugar syrup', 'Tapioca pearls'],
  },
  {
    id: 'taro',
    name: 'Taro Milk Tea',
    emoji: '🟣',
    tagline: 'Sweet, nutty, unmistakably purple',
    ingredients: ['Taro powder or paste', 'Milk', 'Sugar', 'Tapioca pearls'],
  },
  {
    id: 'matcha-latte',
    name: 'Matcha Latte',
    emoji: '🍵',
    tagline: 'Earthy and calm',
    ingredients: ['Ceremonial matcha', 'Milk', 'Simple syrup', 'Ice'],
  },
  {
    id: 'thai-tea',
    name: 'Thai Iced Tea',
    emoji: '🧡',
    tagline: 'Bold, spiced, unapologetically orange',
    ingredients: ['Thai tea mix', 'Condensed milk', 'Evaporated milk', 'Ice'],
  },
  {
    id: 'brown-sugar',
    name: 'Brown Sugar Boba',
    emoji: '🟤',
    tagline: 'Tiger stripes, extra chew',
    ingredients: ['Fresh milk', 'Brown sugar syrup', 'Cooked tapioca pearls'],
  },
  {
    id: 'mango-green',
    name: 'Mango Green Tea',
    emoji: '🥭',
    tagline: 'Bright, fruity, refreshing',
    ingredients: ['Green tea', 'Mango purée', 'Simple syrup', 'Popping boba'],
  },
]

function favKey(user) {
  return `bobaos_favrecipes_${user?.name || 'guest'}`
}

function loadFavs(user) {
  try {
    const raw = window.localStorage.getItem(favKey(user))
    return raw ? JSON.parse(raw) : []
  } catch (e) {
    return []
  }
}

export default function RecipeBook({ user }) {
  const [favorites, setFavorites] = useState(() => loadFavs(user))
  const [expanded, setExpanded] = useState(null)

  useEffect(() => {
    setFavorites(loadFavs(user))
  }, [user])

  useEffect(() => {
    try {
      window.localStorage.setItem(favKey(user), JSON.stringify(favorites))
    } catch (e) {
      // ignore
    }
  }, [favorites, user])

  const toggleFav = (id) => {
    soundManager.hover()
    setFavorites((f) => (f.includes(id) ? f.filter((x) => x !== id) : [...f, id]))
  }

  const sorted = [...RECIPES].sort((a, b) => favorites.includes(b.id) - favorites.includes(a.id))

  return (
    <div className="h-full flex flex-col p-3">
      <div className="flex-1 overflow-y-auto overscroll-contain min-h-0 flex flex-col gap-1.5">
        {sorted.map((r) => {
          const isFav = favorites.includes(r.id)
          const isOpen = expanded === r.id
          return (
            <div key={r.id} className="rounded-xl bg-white/40 overflow-hidden">
              <button
                onClick={() => {
                  soundManager.hover()
                  setExpanded(isOpen ? null : r.id)
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-left touch-manipulation"
              >
                <span className="text-base shrink-0">{r.emoji}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-xs font-semibold text-pearl truncate">{r.name}</span>
                  <span className="block text-[10px] text-pearl/50 truncate">{r.tagline}</span>
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleFav(r.id)
                  }}
                  className="p-1 rounded-full hover:bg-white/60 shrink-0 touch-manipulation"
                  aria-label={isFav ? 'Unfavorite' : 'Favorite'}
                >
                  <Star size={13} className={isFav ? 'fill-taro-dark text-taro-dark' : 'text-pearl/30'} />
                </button>
              </button>
              {isOpen && (
                <ul className="px-3 pb-2.5 pl-9 text-[10px] text-pearl/60 list-disc space-y-0.5">
                  {r.ingredients.map((ing) => (
                    <li key={ing}>{ing}</li>
                  ))}
                </ul>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
