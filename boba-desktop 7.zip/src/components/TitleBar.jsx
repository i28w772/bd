import { Download, Check, Settings } from 'lucide-react'
import BobaLogo from './BobaLogo.jsx'
import ProfileMenu from './ProfileMenu.jsx'
import soundManager from '../utils/soundManager.js'

export default function TitleBar({
  onMinimize,
  onMaximize,
  onClose,
  maximized,
  user,
  onSwitchUser,
  installState,
  onInstallClick,
  onOpenSettings,
  settingsOpen,
}) {
  const dot = (colorClasses, onClick, label) => (
    <button
      aria-label={label}
      onClick={() => {
        soundManager.hover()
        onClick()
      }}
      className="p-1.5 -m-1.5 touch-manipulation"
    >
      <span
        className={`block h-3.5 w-3.5 rounded-full ${colorClasses} transition-transform duration-150 active:scale-95`}
      />
    </button>
  )

  const { installed } = installState || {}

  return (
    <div className="flex items-center justify-between px-3 sm:px-4 py-3 select-none glass border-b border-white/40 rounded-t-2xl">
      <div className="flex items-center gap-1 sm:gap-2">
        {dot('bg-[#FF6159] shadow-[0_0_6px_rgba(255,97,89,0.6)]', onClose, 'Close BobaOS')}
        {dot('bg-[#FFBD2E] shadow-[0_0_6px_rgba(255,189,46,0.6)]', onMinimize, 'Minimize BobaOS')}
        {dot('bg-[#28C940] shadow-[0_0_6px_rgba(40,201,64,0.6)]', onMaximize, maximized ? 'Restore BobaOS' : 'Maximize BobaOS')}
      </div>

      <div className="hidden sm:flex items-center gap-2 text-pearl/80">
        <BobaLogo size={18} />
        <span className="font-display font-medium tracking-wide text-sm">BobaOS — Café Dashboard</span>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2 justify-end">
        {installed ? (
          <span
            className="hidden sm:flex items-center gap-1 pl-2 pr-2.5 py-1 rounded-full bg-matcha/20 text-matcha-dark text-[11px] font-semibold"
            title="BobaOS is installed"
          >
            <Check size={12} /> Installed
          </span>
        ) : (
          <button
            onClick={() => {
              soundManager.hover()
              onInstallClick()
            }}
            title="Install BobaOS"
            className="flex items-center gap-1.5 pl-2 pr-2.5 sm:pr-3 py-1 rounded-full hover:bg-white/50 transition-colors text-pearl/70 touch-manipulation"
          >
            <Download size={15} />
            <span className="hidden sm:inline text-xs font-semibold">Install</span>
          </button>
        )}

        <ProfileMenu user={user} onSwitchUser={onSwitchUser} />

        <button
          aria-label="Settings"
          title="Settings"
          onClick={() => {
            soundManager.hover()
            onOpenSettings()
          }}
          className={`p-1.5 rounded-full transition-colors touch-manipulation ${
            settingsOpen ? 'bg-matcha/25 text-matcha-dark' : 'hover:bg-white/50 text-pearl/70'
          }`}
        >
          <Settings size={16} />
        </button>
      </div>
    </div>
  )
}
