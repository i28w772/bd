import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Sun,
  Moon,
  Laptop,
  Volume2,
  VolumeX,
  RotateCcw,
  UserRound,
  Trash2,
  Info,
} from 'lucide-react'
import { AVATAR_COLORS } from './LoginScreen.jsx'
import { WIDGET_LABELS } from '../utils/useSettings.js'
import { resetStats } from '../utils/stats.js'
import soundManager from '../utils/soundManager.js'

function Section({ title, children }) {
  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border">
      <h3 className="font-display text-sm font-semibold text-pearl mb-3">{title}</h3>
      {children}
    </div>
  )
}

function Switch({ checked, onChange, label }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={onChange}
      className={`relative h-6 w-11 rounded-full transition-colors touch-manipulation shrink-0 ${
        checked ? 'bg-matcha' : 'bg-pearl/20'
      }`}
    >
      <motion.span
        className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow"
        animate={{ left: checked ? 22 : 2 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
      />
    </button>
  )
}

export default function SettingsPage({
  user,
  onUpdateUser,
  onSwitchUser,
  onBack,
  mode,
  setMode,
  muted,
  onToggleMute,
  volume,
  setVolume,
  widgets,
  onToggleWidget,
  onResetWidgets,
  hideHardwareMonitor,
}) {
  const [name, setName] = useState(user?.name || '')
  const [resetConfirm, setResetConfirm] = useState(false)

  const commitName = () => {
    const trimmed = name.trim()
    if (trimmed && trimmed !== user.name) {
      soundManager.click()
      onUpdateUser({ name: trimmed })
    } else {
      setName(user.name)
    }
  }

  const changeColor = (colorId) => {
    soundManager.hover()
    onUpdateUser({ color: colorId })
  }

  const handleResetStats = () => {
    if (!resetConfirm) {
      soundManager.hover()
      setResetConfirm(true)
      return
    }
    soundManager.click()
    resetStats(user)
    setResetConfirm(false)
  }

  const widgetKeys = Object.keys(WIDGET_LABELS).filter((k) => !(k === 'hardware' && hideHardwareMonitor))

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
      <div className="flex items-center gap-2 mb-4">
        <button
          onClick={onBack}
          className="p-1.5 rounded-full hover:bg-white/50 text-pearl/70 transition-colors touch-manipulation"
          aria-label="Back to dashboard"
        >
          <ArrowLeft size={18} />
        </button>
        <h2 className="font-display text-lg font-semibold text-pearl">Settings</h2>
      </div>

      <div className="flex flex-col gap-4 sm:gap-5 max-w-2xl">
        <Section title="Profile">
          <div className="flex flex-col gap-4">
            <div>
              <label className="text-xs text-pearl/60 mb-1.5 block">Display name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                onBlur={commitName}
                onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
                maxLength={18}
                className="w-full sm:w-64 px-3.5 py-2 rounded-full bg-white/60 border border-white/60 text-base text-pearl focus:outline-none focus:ring-2 focus:ring-matcha transition"
              />
            </div>
            <div>
              <label className="text-xs text-pearl/60 mb-1.5 block">Cup color</label>
              <div className="flex gap-2.5">
                {AVATAR_COLORS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => changeColor(c.id)}
                    aria-label={c.label}
                    className={`h-8 w-8 rounded-full border-2 transition-transform touch-manipulation ${
                      user?.color === c.id ? 'border-pearl scale-110' : 'border-white/60'
                    }`}
                    style={{ background: c.hex }}
                  />
                ))}
              </div>
            </div>
          </div>
        </Section>

        <Section title="Appearance">
          <div className="flex gap-2">
            {[
              { id: 'light', label: 'Day Brew', icon: Sun },
              { id: 'dark', label: 'Night Brew', icon: Moon },
              { id: 'system', label: 'System', icon: Laptop },
            ].map((opt) => {
              const Icon = opt.icon
              return (
                <button
                  key={opt.id}
                  onClick={() => {
                    soundManager.hover()
                    setMode(opt.id)
                  }}
                  className={`flex-1 flex flex-col items-center gap-1 py-2.5 rounded-xl text-xs font-semibold transition-colors touch-manipulation ${
                    mode === opt.id ? 'bg-matcha text-white shadow-soft' : 'bg-white/40 text-pearl/60 hover:bg-white/60'
                  }`}
                >
                  <Icon size={16} />
                  {opt.label}
                </button>
              )
            })}
          </div>
        </Section>

        <Section title="Sound">
          <div className="flex items-center gap-3 mb-3">
            <button
              onClick={onToggleMute}
              className="p-2 rounded-full bg-white/40 hover:bg-white/60 text-pearl/70 transition-colors touch-manipulation"
              aria-label={muted ? 'Unmute' : 'Mute'}
            >
              {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              disabled={muted}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              onMouseUp={() => soundManager.click()}
              onTouchEnd={() => soundManager.click()}
              className="flex-1 accent-matcha disabled:opacity-40"
            />
            <span className="text-xs font-mono text-pearl/50 w-9 text-right">{Math.round(volume * 100)}%</span>
          </div>
          <p className="text-[11px] text-pearl/50">
            Every click, pop, and chime is synthesized live with the Web Audio API — nothing to download.
          </p>
        </Section>

        <Section title="Dashboard widgets">
          <div className="flex flex-col divide-y divide-white/30">
            {widgetKeys.map((key) => (
              <div key={key} className="flex items-center justify-between py-2 first:pt-0 last:pb-0">
                <span className="text-sm text-pearl/80">{WIDGET_LABELS[key]}</span>
                <Switch
                  checked={widgets[key]}
                  onChange={() => {
                    soundManager.hover()
                    onToggleWidget(key)
                  }}
                  label={`Toggle ${WIDGET_LABELS[key]}`}
                />
              </div>
            ))}
          </div>
          <button
            onClick={() => {
              soundManager.hover()
              onResetWidgets()
            }}
            className="flex items-center gap-1.5 mt-3 text-xs text-pearl/50 hover:text-pearl/70 transition-colors touch-manipulation"
          >
            <RotateCcw size={12} /> Show all widgets
          </button>
        </Section>

        <Section title="Data & account">
          <div className="flex flex-col gap-2.5">
            <button
              onClick={handleResetStats}
              className={`flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl text-sm transition-colors touch-manipulation ${
                resetConfirm ? 'bg-red-100 text-red-700' : 'bg-white/40 hover:bg-white/60 text-pearl/80'
              }`}
            >
              <span className="flex items-center gap-2">
                <Trash2 size={15} />
                {resetConfirm ? 'Tap again to confirm reset' : 'Reset Boba Punch Card stats'}
              </span>
            </button>
            <button
              onClick={onSwitchUser}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/40 hover:bg-white/60 text-sm text-pearl/80 transition-colors touch-manipulation"
            >
              <UserRound size={15} /> Switch user
            </button>
            <p className="text-[11px] text-pearl/45 leading-snug mt-1">
              Everything above — your name, cup color, theme, volume, widget layout, and punch card stats —
              is stored only in this browser's local storage. Nothing is sent to a server; there's no backend.
            </p>
          </div>
        </Section>

        <Section title="About BobaOS">
          <div className="flex items-start gap-2.5">
            <Info size={15} className="text-taro-dark mt-0.5 shrink-0" />
            <div className="text-xs text-pearl/60 leading-relaxed">
              <p className="mb-2">
                BobaOS is a cozy, boba-tea-themed desktop-style dashboard — built with React, Vite,
                Tailwind CSS, Framer Motion, and Lucide icons.
              </p>
              <p className="mb-1 font-semibold text-pearl/70">Data & map credits</p>
              <ul className="list-disc list-inside space-y-0.5">
                <li>Weather: Open-Meteo</li>
                <li>Nearby places: OpenStreetMap contributors, via the Overpass API</li>
                <li>Map rendering: Leaflet, on OpenStreetMap tiles</li>
                <li>Fonts: Fredoka, Quicksand & JetBrains Mono (Google Fonts)</li>
              </ul>
            </div>
          </div>
        </Section>
      </div>
    </motion.div>
  )
}
