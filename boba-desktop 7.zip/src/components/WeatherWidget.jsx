import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Sun, CloudSun, Cloud, CloudRain, CloudSnow, CloudLightning, RefreshCw, MapPin } from 'lucide-react'
import LoadingSpinner from './LoadingSpinner.jsx'
import soundManager from '../utils/soundManager.js'

const CODE_MAP = {
  0: { label: 'Clear skies', Icon: Sun, boba: 'Perfect temperature for an Iced Taro Milk Tea with extra pearls' },
  1: { label: 'Mostly clear', Icon: CloudSun, boba: 'Great weather for a Brown Sugar Boba on the patio' },
  2: { label: 'Partly cloudy', Icon: CloudSun, boba: 'Cozy skies call for a warm Hojicha Milk Tea' },
  3: { label: 'Overcast', Icon: Cloud, boba: 'Grey skies, golden pearls — Matcha Latte weather' },
  45: { label: 'Foggy', Icon: Cloud, boba: 'Misty out — a Thai Tea will warm you right up' },
  48: { label: 'Foggy', Icon: Cloud, boba: 'Misty out — a Thai Tea will warm you right up' },
  51: { label: 'Light drizzle', Icon: CloudRain, boba: 'Drizzly day, sip a hot Chai Milk Tea by the window' },
  61: { label: 'Rainy', Icon: CloudRain, boba: 'Rain outside, extra pearls inside — stay cozy' },
  71: { label: 'Snowy', Icon: CloudSnow, boba: 'Snow day! A hot Black Sugar Milk Tea is calling' },
  95: { label: 'Thunderstorms', Icon: CloudLightning, boba: 'Storm brewing — same for your Wintermelon Tea' },
}

function codeInfo(code) {
  return CODE_MAP[code] || CODE_MAP[1]
}

export default function WeatherWidget() {
  const [status, setStatus] = useState('loading') // loading | ready | error
  const [data, setData] = useState(null)
  const [place, setPlace] = useState('Your area')

  const load = () => {
    setStatus('loading')
    if (!navigator.geolocation) {
      fallback()
      return
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords
          const res = await fetch(
            `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weathercode&daily=temperature_2m_max,temperature_2m_min,weathercode&temperature_unit=fahrenheit&timezone=auto`
          )
          const json = await res.json()
          setData(json)
          setPlace('Your location')
          setStatus('ready')
        } catch (e) {
          fallback()
        }
      },
      () => fallback(),
      { timeout: 4000 }
    )
  }

  const fallback = async () => {
    try {
      // Default to a pleasant café city if geolocation is unavailable
      const res = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=35.6762&longitude=139.6503&current=temperature_2m,weathercode&daily=temperature_2m_max,temperature_2m_min,weathercode&temperature_unit=fahrenheit&timezone=auto`
      )
      const json = await res.json()
      setData(json)
      setPlace('Tokyo (default)')
      setStatus('ready')
    } catch (e) {
      setStatus('error')
    }
  }

  useEffect(() => {
    load()
  }, [])

  const info = data ? codeInfo(data.current?.weathercode) : null
  const Icon = info?.Icon || Sun

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5">
          <MapPin size={14} className="text-taro-dark" /> Boba Weather
        </h3>
        <button
          onClick={() => {
            soundManager.click()
            load()
          }}
          className="p-1.5 rounded-full hover:bg-white/50 text-pearl/60 transition-colors"
          aria-label="Refresh weather"
        >
          <RefreshCw size={14} className={status === 'loading' ? 'animate-spin' : ''} />
        </button>
      </div>

      {status === 'loading' && (
        <div className="flex-1 flex items-center justify-center py-4">
          <LoadingSpinner size={40} label="Brewing forecast…" />
        </div>
      )}

      {status === 'error' && (
        <p className="text-sm text-pearl/60 flex-1 flex items-center">Couldn't fetch the forecast right now.</p>
      )}

      {status === 'ready' && data && (
        <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="flex-1 flex flex-col justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-2xl bg-milk/60">
              <Icon size={34} className="text-taro-dark" strokeWidth={1.7} />
            </div>
            <div>
              <p className="text-3xl font-display font-semibold text-pearl leading-none">
                {Math.round(data.current?.temperature_2m)}°F
              </p>
              <p className="text-xs text-pearl/60 mt-1">{place} · {info.label}</p>
            </div>
          </div>

          <p className="text-sm text-pearl/80 mt-4 bg-milk/50 rounded-xl px-3 py-2 leading-snug">
            🧋 {info.boba}
          </p>

          {data.daily && (
            <div className="mt-4 flex justify-between text-xs text-pearl/70">
              <span>H: {Math.round(data.daily.temperature_2m_max?.[0])}°</span>
              <span>L: {Math.round(data.daily.temperature_2m_min?.[0])}°</span>
            </div>
          )}
        </motion.div>
      )}
    </div>
  )
}
