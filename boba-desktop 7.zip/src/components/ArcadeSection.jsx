import { useRef, useState } from 'react'
import { Gamepad2 } from 'lucide-react'
import CatchBobaGame from './games/CatchBobaGame.jsx'
import TeaMerge2048 from './games/TeaMerge2048.jsx'
import MemoryMatch from './games/MemoryMatch.jsx'
import soundManager from '../utils/soundManager.js'
import { useContainerWidth } from '../utils/useContainerWidth.js'

const TABS = [
  { id: 'catch', label: 'Catch the Boba' },
  { id: 'merge', label: 'Tea Merge' },
  { id: 'memory', label: 'Boba Memory' },
]

export default function ArcadeSection({ user }) {
  const [tab, setTab] = useState('catch')
  const stageRef = useRef(null)
  const stageWidth = useContainerWidth(stageRef)

  return (
    <div className="glass rounded-2xl p-3 sm:p-5 shadow-soft glow-border">
      <div className="flex items-center justify-between mb-4 px-1 flex-wrap gap-2">
        <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5">
          <Gamepad2 size={14} className="text-taro-dark" /> Mini Arcade
        </h3>
        <div className="flex gap-1 bg-white/40 rounded-full p-1">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                soundManager.click()
                setTab(t.id)
              }}
              className={`px-2.5 sm:px-3 py-1 rounded-full text-[11px] sm:text-xs font-semibold transition-colors touch-manipulation ${
                tab === t.id ? 'bg-matcha text-white shadow-soft' : 'text-pearl/60 hover:bg-white/50'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>
      <div ref={stageRef} className="flex justify-center w-full">
        {tab === 'catch' && <CatchBobaGame maxWidth={stageWidth} user={user} />}
        {tab === 'merge' && <TeaMerge2048 maxWidth={stageWidth} user={user} />}
        {tab === 'memory' && <MemoryMatch maxWidth={stageWidth} />}
      </div>
    </div>
  )
}
