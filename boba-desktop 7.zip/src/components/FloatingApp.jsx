import { motion, useDragControls } from 'framer-motion'
import soundManager from '../utils/soundManager.js'

export default function FloatingApp({
  title,
  icon: Icon,
  size,
  position,
  minimized,
  maximized,
  zIndex,
  onFocus,
  onClose,
  onMinimize,
  onMaximize,
  onDragEnd,
  children,
}) {
  const dragControls = useDragControls()

  const startDrag = (e) => {
    onFocus?.()
    if (!maximized) dragControls.start(e)
  }

  const dot = (colorClasses, onClick, label) => (
    <button
      aria-label={label}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={() => {
        soundManager.hover()
        onClick()
      }}
      className="p-1 -m-1 touch-manipulation"
    >
      <span
        className={`block h-2.5 w-2.5 rounded-full ${colorClasses} transition-transform duration-150 active:scale-95`}
      />
    </button>
  )

  const targetX = maximized ? 16 : position.x
  const targetY = maximized ? 16 : position.y

  return (
    <motion.div
      drag={!maximized}
      dragListener={false}
      dragControls={dragControls}
      dragMomentum={false}
      dragElastic={0.04}
      onPointerDownCapture={onFocus}
      initial={{ opacity: 0, scale: 0.92, x: position.x, y: position.y }}
      animate={{
        opacity: minimized ? 0 : 1,
        scale: minimized ? 0.5 : 1,
        x: targetX,
        y: targetY,
      }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ type: 'spring', stiffness: 320, damping: 30 }}
      onDragEnd={(e, info) => {
        onDragEnd?.({ x: position.x + info.offset.x, y: position.y + info.offset.y })
      }}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: maximized ? 'calc(100vw - 32px)' : size.width,
        height: maximized ? 'calc(100vh - 32px)' : size.height,
        zIndex,
        pointerEvents: minimized ? 'none' : 'auto',
      }}
      className="max-w-[92vw]"
    >
      <div className="rounded-2xl overflow-hidden shadow-soft glow-border glass flex flex-col h-full">
        {/* Drag only initiates from this handle — content below gets normal, uninterrupted clicks/typing. */}
        <div
          onPointerDown={startDrag}
          onDoubleClick={() => onMaximize?.()}
          className="flex items-center justify-between px-3 py-2 border-b border-white/40 bg-white/20 cursor-grab active:cursor-grabbing shrink-0 touch-none"
        >
          <div className="flex items-center gap-1.5">
            {dot('bg-[#FF6159] shadow-[0_0_4px_rgba(255,97,89,0.6)]', onClose, `Close ${title}`)}
            {dot('bg-[#FFBD2E] shadow-[0_0_4px_rgba(255,189,46,0.6)]', onMinimize, `Minimize ${title}`)}
            {dot(
              'bg-[#28C940] shadow-[0_0_4px_rgba(40,201,64,0.6)]',
              onMaximize,
              maximized ? `Restore ${title}` : `Maximize ${title}`
            )}
          </div>
          <span className="flex items-center gap-1.5 text-[11px] font-display font-semibold text-pearl select-none pr-1">
            {Icon && <Icon size={12} className="text-taro-dark" />}
            {title}
          </span>
        </div>
        <div className="flex-1 min-h-0" style={{ touchAction: 'manipulation' }}>
          {children}
        </div>
      </div>
    </motion.div>
  )
}
