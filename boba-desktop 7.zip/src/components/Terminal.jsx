import { useEffect, useRef, useState } from 'react'
import soundManager from '../utils/soundManager.js'
import { detectDevice } from '../utils/device.js'
import { getStats } from '../utils/stats.js'

const JOKES = [
  'Why did the boba pearl break up with the straw? It felt taken for granted.',
  'I whisked my matcha and now it whisks me back sometimes.',
  'A watched kettle never boils, but a watched brew timer definitely does.',
  "I'm on a strict diet of tea and better decisions. Mostly tea.",
]

const FORTUNES = [
  'A new flavor awaits you this week.',
  'Extra pearls are in your future.',
  'Someone will ask to share your drink. Say no.',
  'Good things come to those who wait for the tea to steep.',
  'A quiet afternoon and a full cup — that is enough.',
]

const FILES = {
  'menu.txt': 'Milk Tea · Taro · Matcha Latte · Thai Tea · Brown Sugar Boba · Mango Green Tea',
  'hours.txt': 'Mon-Fri 8am-9pm, Sat-Sun 9am-10pm',
  'secret.txt': "You found it. There's no secret. Just boba.",
}

function line(text, tone = 'out') {
  return { id: `${Date.now()}-${Math.random()}`, text, tone }
}

function formatUptime(ms) {
  const s = Math.floor(ms / 1000)
  const m = Math.floor(s / 60)
  const rem = s % 60
  return m > 0 ? `${m}m ${rem}s` : `${rem}s`
}

const HELP_TEXT = [
  'help, whoami, date, time, echo <text>, boba, sysinfo, neofetch',
  'theme <day|night|system>, color <matcha|taro|milk|blush|pearl>, rename <name>',
  'volume <0-100>, mute, unmute, open <notes|ambience|recipes|converter|settings>',
  'close <notes|ambience|recipes|converter>, ls, cat <file>, calc <expr>',
  'stats, apps, joke, fortune, history, uptime, clear, logout',
]

function runCommand(raw, ctx) {
  const [name, ...rest] = raw.trim().split(/\s+/)
  const argRaw = rest.join(' ')
  const arg = argRaw.toLowerCase()
  const cmd = (name || '').toLowerCase()

  switch (cmd) {
    case '':
      return []
    case 'help':
      return HELP_TEXT.map((t) => line(t))
    case 'whoami':
      return [line(ctx.user?.name || 'guest')]
    case 'date':
      return [line(new Date().toString())]
    case 'time':
      return [line(new Date().toLocaleTimeString())]
    case 'echo':
      return [line(argRaw)]
    case 'boba':
      return [line('   ___'), line('  |~ ~|'), line('  |o o|  🧋'), line('  |___|'), line('life is short, drink boba')]
    case 'sysinfo': {
      const info = detectDevice()
      return [
        line(`device: ${info.deviceType}`),
        line(`os: ${info.os}`),
        line(`browser: ${info.browser}`),
        line(`input: ${info.isTouch ? 'touch' : 'mouse'}`),
        line(`screen: ${info.width}x${info.height} @${info.pixelRatio}x`),
      ]
    }
    case 'neofetch': {
      const info = detectDevice()
      return [
        line('      🧋      ' + (ctx.user?.name || 'guest') + '@bobaos'),
        line('     /||\\     ------------------'),
        line('    | || |    os: ' + info.os),
        line('    |____|    device: ' + info.deviceType),
        line('              browser: ' + info.browser),
        line('              uptime: ' + formatUptime(Date.now() - ctx.bootTime)),
      ]
    }
    case 'theme':
      if (arg === 'night' || arg === 'dark') {
        ctx.setMode('dark')
        return [line('Switched to Night Brew.')]
      }
      if (arg === 'day' || arg === 'light') {
        ctx.setMode('light')
        return [line('Switched to Day Brew.')]
      }
      if (arg === 'system') {
        ctx.setMode('system')
        return [line('Following system theme.')]
      }
      return [line('Usage: theme <day|night|system>', 'err')]
    case 'color': {
      const valid = ['matcha', 'taro', 'milk', 'blush', 'pearl']
      if (!valid.includes(arg)) return [line(`Usage: color <${valid.join('|')}>`, 'err')]
      ctx.onUpdateUser({ color: arg })
      return [line(`Cup color set to ${arg}.`)]
    }
    case 'rename': {
      const newName = argRaw.trim().slice(0, 18)
      if (!newName) return [line('Usage: rename <new name>', 'err')]
      ctx.onUpdateUser({ name: newName })
      return [line(`Renamed to ${newName}.`)]
    }
    case 'volume': {
      const n = parseInt(arg, 10)
      if (Number.isNaN(n) || n < 0 || n > 100) return [line('Usage: volume <0-100>', 'err')]
      ctx.setVolume(n / 100)
      return [line(`Volume set to ${n}%.`)]
    }
    case 'mute':
      ctx.setMuted(true)
      return [line('Muted.')]
    case 'unmute':
      ctx.setMuted(false)
      return [line('Unmuted.')]
    case 'open': {
      if (arg === 'terminal') return [line("You're already here.")]
      if (['notes', 'ambience', 'recipes', 'converter'].includes(arg)) {
        ctx.onOpenApp(arg)
        return [line(`Opening ${arg}…`)]
      }
      if (arg === 'settings') {
        ctx.onOpenSettings()
        return [line('Opening settings…')]
      }
      return [line(`unknown app: ${arg} (try notes, ambience, recipes, converter, settings)`, 'err')]
    }
    case 'close': {
      if (['notes', 'ambience', 'recipes', 'converter'].includes(arg)) {
        ctx.onCloseApp(arg)
        return [line(`Closed ${arg}.`)]
      }
      return [line(`unknown app: ${arg}`, 'err')]
    }
    case 'apps':
      return ['terminal', 'notes', 'ambience', 'recipes', 'converter'].map((id) => {
        const w = ctx.openApps?.[id]
        const status = !w?.open ? 'closed' : w.minimized ? 'minimized' : 'open'
        return line(`${id}: ${status}`)
      })
    case 'ls':
      return [line(Object.keys(FILES).join('  '))]
    case 'cat': {
      const file = argRaw.trim()
      if (!file) return [line('Usage: cat <file>', 'err')]
      if (!FILES[file]) return [line(`cat: ${file}: no such file`, 'err')]
      return [line(FILES[file])]
    }
    case 'calc': {
      if (!argRaw || !/^[0-9+\-*/().%\s]+$/.test(argRaw)) return [line('calc: invalid expression', 'err')]
      try {
        // eslint-disable-next-line no-new-func
        const result = Function(`"use strict"; return (${argRaw})`)()
        return [line(String(result))]
      } catch (e) {
        return [line('calc: could not evaluate', 'err')]
      }
    }
    case 'stats': {
      const s = getStats(ctx.user)
      return [
        line(`visits: ${s.visits}  streak: ${s.streak}`),
        line(`pearls caught: ${s.pearlsCaught}`),
        line(`best catch score: ${s.bestCatchScore}  best merge: ${s.bestMergeScore}`),
      ]
    }
    case 'joke':
      return [line(JOKES[Math.floor(Math.random() * JOKES.length)])]
    case 'fortune':
      return [line(FORTUNES[Math.floor(Math.random() * FORTUNES.length)])]
    case 'history':
      return ctx.pastCommands.length
        ? ctx.pastCommands.map((c, i) => line(`${i + 1}  ${c}`))
        : [line('No commands yet.')]
    case 'uptime':
      return [line(`shell session uptime: ${formatUptime(Date.now() - ctx.bootTime)}`)]
    case 'clear':
      return 'CLEAR'
    case 'logout':
    case 'exit':
      ctx.onSwitchUser()
      return [line('Logged out. See you next time! 🧋')]
    default:
      return [line(`command not found: ${cmd} (try 'help')`, 'err')]
  }
}

export default function Terminal({
  user,
  setMode,
  onUpdateUser,
  onOpenApp,
  onCloseApp,
  onOpenSettings,
  openApps,
  setMuted,
  setVolume,
  onSwitchUser,
}) {
  const [history, setHistory] = useState([line('BobaShell v1.1 — type "help" to see what this does.')])
  const [input, setInput] = useState('')
  const [pastCommands, setPastCommands] = useState([])
  const [historyIdx, setHistoryIdx] = useState(-1)
  const scrollRef = useRef(null)
  const bootTimeRef = useRef(Date.now())

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight })
  }, [history])

  const submit = (e) => {
    e.preventDefault()
    const cmdText = input
    setInput('')
    if (!cmdText.trim()) return

    soundManager.hover()
    const nextPast = [...pastCommands, cmdText]
    const result = runCommand(cmdText, {
      user,
      setMode,
      onUpdateUser,
      onOpenApp,
      onCloseApp,
      onOpenSettings,
      openApps,
      setMuted,
      setVolume,
      onSwitchUser,
      pastCommands,
      bootTime: bootTimeRef.current,
    })

    setPastCommands(nextPast)
    setHistoryIdx(-1)

    if (result === 'CLEAR') {
      setHistory([])
      return
    }
    setHistory((h) => [...h, line(`$ ${cmdText}`, 'in'), ...result])
  }

  const onKeyDown = (e) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (pastCommands.length === 0) return
      const nextIdx = historyIdx === -1 ? pastCommands.length - 1 : Math.max(0, historyIdx - 1)
      setHistoryIdx(nextIdx)
      setInput(pastCommands[nextIdx])
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (historyIdx === -1) return
      const nextIdx = historyIdx + 1
      if (nextIdx >= pastCommands.length) {
        setHistoryIdx(-1)
        setInput('')
      } else {
        setHistoryIdx(nextIdx)
        setInput(pastCommands[nextIdx])
      }
    }
  }

  return (
    <div className="h-full flex flex-col p-3 gap-2">
      <div
        ref={scrollRef}
        className="flex-1 min-h-0 overflow-y-auto overscroll-contain rounded-xl bg-[#1e1712] px-3 py-2.5 font-mono text-[11px] leading-relaxed"
      >
        {history.map((l) => (
          <div
            key={l.id}
            className={l.tone === 'err' ? 'text-[#e39a8a]' : l.tone === 'in' ? 'text-[#8CA779]' : 'text-[#d9c9ae]'}
          >
            {l.text}
          </div>
        ))}
      </div>

      <form onSubmit={submit} className="flex items-center gap-2 rounded-full bg-[#1e1712] px-3 py-1.5 shrink-0">
        <span className="font-mono text-[11px] text-[#8CA779]">$</span>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder="type a command…"
          className="flex-1 bg-transparent outline-none font-mono text-base text-[#d9c9ae] placeholder:text-[#7a6a54]"
        />
      </form>
    </div>
  )
}
