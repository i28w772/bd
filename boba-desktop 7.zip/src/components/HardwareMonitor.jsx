import { useEffect, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { Cpu, MemoryStick, Gauge } from 'lucide-react'

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v))
}

// Browsers deliberately don't expose real system-wide CPU/GPU/RAM usage
// (that would be a privacy/fingerprinting risk), so these are the closest
// genuinely real, live-measured signals a web page can get:
//
//  - CPU: logical core count (navigator.hardwareConcurrency) is real.
//    "Load" is inferred from how late requestAnimationFrame callbacks land
//    relative to the ~16.7ms frame budget — real jank/contention, not a
//    literal "% busy across all cores" figure.
//  - RAM: performance.memory (Chrome/Edge only) reports this tab's actual
//    JS heap usage. Where that's unavailable, navigator.deviceMemory gives
//    an approximate device memory tier. If neither exists, we say so.
//  - GPU: WebGL's debug renderer info reveals the real GPU/renderer name
//    where the browser allows it. "Load" is derived from live measured
//    frames-per-second versus a 60fps baseline.

function useMainThreadLoad() {
  const [load, setLoad] = useState(0)
  const emaRef = useRef(0)
  const lastRef = useRef(performance.now())

  useEffect(() => {
    let raf
    const tick = (t) => {
      const dt = t - lastRef.current
      lastRef.current = t
      const overBudget = clamp(((dt - 16.7) / 16.7) * 100, 0, 100)
      emaRef.current = emaRef.current * 0.85 + overBudget * 0.15
      setLoad(emaRef.current)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  return load
}

function useFps() {
  const [fps, setFps] = useState(60)

  useEffect(() => {
    let raf
    let frames = 0
    let windowStart = performance.now()
    const tick = (t) => {
      frames += 1
      const elapsed = t - windowStart
      if (elapsed >= 500) {
        setFps(Math.round((frames * 1000) / elapsed))
        frames = 0
        windowStart = t
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  return fps
}

function getGpuInfo() {
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    if (!gl) return null
    const ext = gl.getExtension('WEBGL_debug_renderer_info')
    const renderer = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER)
    if (!renderer) return null
    return renderer.length > 46 ? `${renderer.slice(0, 46)}…` : renderer
  } catch (e) {
    return null
  }
}

function getMemoryInfo() {
  if (typeof performance !== 'undefined' && performance.memory) {
    const { usedJSHeapSize, jsHeapSizeLimit } = performance.memory
    return {
      type: 'heap',
      usedMB: usedJSHeapSize / 1048576,
      limitMB: jsHeapSizeLimit / 1048576,
      percent: clamp((usedJSHeapSize / jsHeapSizeLimit) * 100, 0, 100),
    }
  }
  if (navigator.deviceMemory) {
    return { type: 'device', gb: navigator.deviceMemory, percent: clamp((navigator.deviceMemory / 8) * 100, 0, 100) }
  }
  return null
}

function Tank({ label, percent, caption, color, Icon, unavailable }) {
  return (
    <div className="flex flex-col items-center gap-2 w-[4.5rem]">
      <div className="relative h-32 w-14 rounded-full overflow-hidden border-2 border-pearl/70 bg-cream shadow-inner">
        {!unavailable && (
          <motion.div
            className="absolute bottom-0 left-0 right-0"
            style={{ background: color }}
            animate={{ height: `${percent}%` }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          >
            <div className="w-full h-2 shimmer-bg animate-shimmer opacity-60" />
            {/* boba pearls floating inside the tank */}
            <span className="absolute left-2 bottom-3 h-2 w-2 rounded-full bg-pearl/70 animate-wobble" />
            <span className="absolute right-2 bottom-6 h-1.5 w-1.5 rounded-full bg-pearl/60 animate-wobble" style={{ animationDelay: '0.4s' }} />
            <span className="absolute left-4 bottom-9 h-1.5 w-1.5 rounded-full bg-pearl/50 animate-wobble" style={{ animationDelay: '0.9s' }} />
          </motion.div>
        )}
        <div className="absolute inset-x-0 top-1 flex justify-center text-pearl/50">
          <Icon size={14} />
        </div>
      </div>
      <span className="text-xs font-semibold text-pearl">{label}</span>
      <span className="font-mono text-[10px] text-pearl/60 text-center leading-tight">{caption}</span>
    </div>
  )
}

export default function HardwareMonitor() {
  const cpuLoad = useMainThreadLoad()
  const fps = useFps()
  const [mem, setMem] = useState(() => getMemoryInfo())
  const [gpuName] = useState(() => getGpuInfo())
  const cores = navigator.hardwareConcurrency || null

  useEffect(() => {
    const id = setInterval(() => setMem(getMemoryInfo()), 1500)
    return () => clearInterval(id)
  }, [])

  const gpuPercent = clamp((fps / 60) * 100, 0, 100)

  return (
    <div className="glass rounded-2xl p-4 sm:p-5 shadow-soft glow-border h-full flex flex-col">
      <h3 className="font-display text-sm font-semibold text-pearl flex items-center gap-1.5 mb-3">
        <Gauge size={14} className="text-taro-dark" /> Boba Tank Levels
      </h3>
      <div className="flex-1 flex items-center justify-around">
        <Tank
          label="CPU"
          percent={cpuLoad}
          caption={cores ? `${cores} cores · ${Math.round(cpuLoad)}%` : `${Math.round(cpuLoad)}% load`}
          color="linear-gradient(180deg,#D9B98A,#B39CD0)"
          Icon={Cpu}
        />
        <Tank
          label="GPU"
          percent={gpuPercent}
          caption={`${fps} fps`}
          color="linear-gradient(180deg,#C9E0C0,#8CA779)"
          Icon={Gauge}
        />
        <Tank
          label="RAM"
          percent={mem ? mem.percent : 0}
          caption={
            mem
              ? mem.type === 'heap'
                ? `${Math.round(mem.usedMB)}/${Math.round(mem.limitMB)} MB`
                : `~${mem.gb} GB device`
              : 'n/a here'
          }
          color="linear-gradient(180deg,#F3C9D4,#B39CD0)"
          Icon={MemoryStick}
          unavailable={!mem}
        />
      </div>
      <p className="text-[10px] text-pearl/45 text-center mt-3 leading-snug px-1">
        Real, browser-measured signals — not full system stats (browsers can't see those, by design).
        {gpuName ? ` GPU: ${gpuName}` : ' GPU name hidden by this browser.'}
      </p>
    </div>
  )
}
