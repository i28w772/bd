import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { TerminalSquare, StickyNote, Music, BookOpen, Ruler } from 'lucide-react'
import BobaLogo from './BobaLogo.jsx'
import soundManager from '../utils/soundManager.js'

const DESKTOP_APPS = [
  { id: 'bobaos', label: 'BobaOS' },
  { id: 'terminal', label: 'BobaShell', icon: TerminalSquare },
  { id: 'notes', label: 'Boba Notes', icon: StickyNote },
  { id: 'ambience', label: 'Café Ambience', icon: Music },
  { id: 'recipes', label: 'Recipe Book', icon: BookOpen },
  { id: 'converter', label: 'Unit Converter', icon: Ruler },
]

function MenuBarClock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000 * 30)
    return () => clearInterval(id)
  }, [])
  return (
    <span className="font-mono tabular-nums">
      {now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
      {'  '}
      {now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}
    </span>
  )
}

export default function Desktop({ onOpenApp }) {
  const [selected, setSelected] = useState(null)

  const handleIconActivate = (id) => {
    if (selected === id) {
      soundManager.click()
      onOpenApp(id)
      setSelected(null)
    } else {
      soundManager.hover()
      setSelected(id)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="absolute inset-0 flex flex-col rounded-2xl overflow-hidden"
      onClick={() => setSelected(null)}
    >
      {/* macOS-style top menu bar */}
      <div className="flex items-center justify-between px-4 py-1.5 glass border-b border-white/30 text-[11px] text-pearl/80 font-display font-medium select-none shrink-0">
        <span className="flex items-center gap-1.5">
          <BobaLogo size={14} /> BobaOS
        </span>
        <MenuBarClock />
      </div>

      {/* desktop surface */}
      <div className="relative flex-1">
        <div className="absolute top-6 right-6 flex flex-col gap-4 items-center">
          {DESKTOP_APPS.map((app) => {
            const Icon = app.icon
            const isSelected = selected === app.id
            return (
              <button
                key={app.id}
                onClick={(e) => {
                  e.stopPropagation()
                  handleIconActivate(app.id)
                }}
                onDoubleClick={(e) => {
                  e.stopPropagation()
                  soundManager.click()
                  onOpenApp(app.id)
                  setSelected(null)
                }}
                className={`flex flex-col items-center gap-1.5 w-20 py-2 rounded-xl touch-manipulation transition-colors ${
                  isSelected ? 'bg-taro/25' : 'hover:bg-white/15'
                }`}
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/45 border border-white/50 shadow-soft">
                  {app.id === 'bobaos' ? <BobaLogo size={28} /> : <Icon size={22} className="text-taro-dark" />}
                </span>
                <span className="text-[11px] text-pearl/85 text-center leading-tight">{app.label}</span>
              </button>
            )
          })}
        </div>

        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 text-center px-4 pointer-events-none">
          <p className="text-[11px] text-pearl/40">Tap an icon, then tap again to open — or double-click</p>
        </div>
      </div>
    </motion.div>
  )
}
