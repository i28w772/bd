import { motion, AnimatePresence } from 'framer-motion'
import { TerminalSquare, StickyNote, Music, BookOpen, Ruler } from 'lucide-react'
import BobaLogo from './BobaLogo.jsx'
import soundManager from '../utils/soundManager.js'

const DOCK_APPS = [
  { id: 'terminal', label: 'BobaShell', icon: TerminalSquare },
  { id: 'notes', label: 'Boba Notes', icon: StickyNote },
  { id: 'ambience', label: 'Café Ambience', icon: Music },
  { id: 'recipes', label: 'Recipe Book', icon: BookOpen },
  { id: 'converter', label: 'Unit Converter', icon: Ruler },
]

export default function Dock({ minimized, onRestore, windows, onToggleApp }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 flex justify-center z-40">
      <motion.div
        layout
        className="pointer-events-auto glass rounded-2xl px-3 py-2 flex items-end gap-3 shadow-soft glow-border"
      >
        <AnimatePresence>
          {minimized && (
            <motion.button
              key="minimized-icon"
              initial={{ opacity: 0, y: 30, scale: 0.6 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.6 }}
              whileHover={{ y: -8 }}
              onClick={() => {
                soundManager.maximize()
                onRestore()
              }}
              className="relative flex flex-col items-center justify-center h-12 w-12 rounded-xl bg-milk/70 border border-white/50 shadow-soft touch-manipulation"
              title="Restore BobaOS"
            >
              <BobaLogo size={26} />
              <span className="absolute -bottom-1.5 h-1.5 w-1.5 rounded-full bg-matcha" />
            </motion.button>
          )}
        </AnimatePresence>

        <div className="w-px h-8 self-center bg-white/40" />

        {DOCK_APPS.map(({ id, label, icon: Icon }) => {
          const w = windows?.[id]
          return (
            <motion.button
              key={id}
              whileHover={{ y: -8, scale: 1.08 }}
              onClick={() => {
                soundManager.hover()
                onToggleApp(id)
              }}
              className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-white/40 hover:bg-white/60 border border-white/40 text-pearl/70 transition-colors touch-manipulation"
              title={label}
              aria-label={label}
            >
              <Icon size={18} />
              {w?.open && (
                <span className={`absolute -bottom-1.5 h-1.5 w-1.5 rounded-full ${w.minimized ? 'bg-taro/40' : 'bg-taro'}`} />
              )}
            </motion.button>
          )
        })}
      </motion.div>
    </div>
  )
}
