import { useEffect, useState } from 'react'
import { Plus, X } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

const COLORS = ['#F3C9D4', '#D8C9E9', '#B7CBA3', '#F0B99B', '#EEDFC2']

function notesKey(user) {
  return `bobaos_notes_${user?.name || 'guest'}`
}

function load(user) {
  try {
    const raw = window.localStorage.getItem(notesKey(user))
    return raw ? JSON.parse(raw) : []
  } catch (e) {
    return []
  }
}

export default function StickyNotes({ user }) {
  const [notes, setNotes] = useState(() => load(user))

  useEffect(() => {
    setNotes(load(user))
  }, [user])

  useEffect(() => {
    try {
      window.localStorage.setItem(notesKey(user), JSON.stringify(notes))
    } catch (e) {
      // ignore
    }
  }, [notes, user])

  const addNote = () => {
    soundManager.click()
    const color = COLORS[Math.floor(Math.random() * COLORS.length)]
    setNotes((n) => [...n, { id: `${Date.now()}`, text: '', color }])
  }

  const updateNote = (id, text) => setNotes((n) => n.map((note) => (note.id === id ? { ...note, text } : note)))

  const removeNote = (id) => {
    soundManager.hover()
    setNotes((n) => n.filter((note) => note.id !== id))
  }

  return (
    <div className="h-full flex flex-col p-3">
      <div className="flex items-center justify-end mb-2 shrink-0">
        <button
          onClick={addNote}
          className="flex items-center gap-1 text-[11px] font-semibold text-matcha-dark hover:text-pearl px-2 py-1 rounded-full hover:bg-white/50 transition-colors touch-manipulation"
        >
          <Plus size={13} /> New note
        </button>
      </div>

      <div className="flex-1 overflow-y-auto overscroll-contain min-h-0">
        {notes.length === 0 ? (
          <p className="text-xs text-pearl/40 text-center py-8 px-2">No notes yet — tap "New note" to jot something down.</p>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            {notes.map((note) => (
              <div key={note.id} className="relative rounded-lg p-2 pt-5" style={{ background: note.color }}>
                <button
                  onClick={() => removeNote(note.id)}
                  className="absolute top-1 right-1 p-0.5 rounded-full hover:bg-black/10 text-pearl/50 transition-colors touch-manipulation"
                  aria-label="Delete note"
                >
                  <X size={11} />
                </button>
                <textarea
                  value={note.text}
                  onChange={(e) => updateNote(note.id, e.target.value)}
                  placeholder="Write something…"
                  rows={3}
                  className="w-full bg-transparent text-base text-pearl/90 resize-none outline-none placeholder:text-pearl/40"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
