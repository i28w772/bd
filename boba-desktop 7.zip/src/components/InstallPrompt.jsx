import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Download, Share, X } from 'lucide-react'
import soundManager from '../utils/soundManager.js'

const DISMISS_KEY = 'bobaos_install_dismissed'

/**
 * A dismissible banner under the title bar. Shows automatically the first
 * time installation becomes available, and can also be triggered manually
 * (e.g. by the title-bar Install button on platforms with no native prompt).
 */
export default function InstallPrompt({ canInstall, installed, isIOS, promptInstall, forceOpen, onForceOpenHandled }) {
  const [dismissed, setDismissed] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    try {
      if (window.localStorage.getItem(DISMISS_KEY) === '1') setDismissed(true)
    } catch (e) {
      // ignore
    }
  }, [])

  // Auto-surface once installability is detected, unless previously dismissed.
  useEffect(() => {
    if ((canInstall || isIOS) && !installed && !dismissed) setOpen(true)
  }, [canInstall, isIOS, installed, dismissed])

  // Manual trigger from the title-bar button always opens it, even if dismissed before.
  useEffect(() => {
    if (forceOpen) {
      setOpen(true)
      onForceOpenHandled?.()
    }
  }, [forceOpen, onForceOpenHandled])

  const dismiss = () => {
    soundManager.hover()
    setOpen(false)
    setDismissed(true)
    try {
      window.localStorage.setItem(DISMISS_KEY, '1')
    } catch (e) {
      // ignore
    }
  }

  const install = async () => {
    soundManager.click()
    const outcome = await promptInstall()
    if (outcome !== 'unavailable') setOpen(false)
  }

  if (installed) return null

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -12 }}
          className="mx-4 sm:mx-6 mt-3 mb-1 flex items-center gap-2.5 rounded-xl bg-milk/70 border border-white/50 px-3 py-2 text-xs text-pearl/80"
        >
          {canInstall ? (
            <>
              <Download size={14} className="text-taro-dark shrink-0" />
              <span className="flex-1">Install BobaOS as an app for the full desktop-style experience.</span>
              <button
                onClick={install}
                className="px-3 py-1 rounded-full bg-matcha text-white font-semibold shrink-0 hover:brightness-105 active:scale-95 transition touch-manipulation"
              >
                Install
              </button>
            </>
          ) : isIOS ? (
            <>
              <Share size={14} className="text-taro-dark shrink-0" />
              <span className="flex-1">
                Tap Share, then "Add to Home Screen" for the full-screen app experience.
              </span>
            </>
          ) : (
            <>
              <Download size={14} className="text-taro-dark shrink-0" />
              <span className="flex-1">
                This browser doesn't support one-click install — try Chrome or Edge on desktop or Android.
              </span>
            </>
          )}
          <button
            onClick={dismiss}
            aria-label="Dismiss"
            className="p-1 rounded-full hover:bg-white/60 shrink-0 touch-manipulation"
          >
            <X size={13} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
