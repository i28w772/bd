import { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Minus,
  Maximize2,
  X,
  UserRound,
  Download,
  CloudSun,
  Clock as ClockIcon,
  Gauge,
  Monitor,
  Timer,
  Trophy,
  Gamepad2,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Calculator as CalculatorIcon,
  MapPin,
  Settings as SettingsIcon,
  StickyNote,
  TerminalSquare,
  Music,
  BookOpen,
  Ruler,
  LayoutGrid,
} from 'lucide-react'
import TitleBar from './components/TitleBar.jsx'
import Dock from './components/Dock.jsx'
import Desktop from './components/Desktop.jsx'
import WeatherWidget from './components/WeatherWidget.jsx'
import ClockWidget from './components/ClockWidget.jsx'
import HardwareMonitor from './components/HardwareMonitor.jsx'
import DeviceInfo from './components/DeviceInfo.jsx'
import InstallPrompt from './components/InstallPrompt.jsx'
import ArcadeSection from './components/ArcadeSection.jsx'
import BrewTimer from './components/BrewTimer.jsx'
import PunchCard from './components/PunchCard.jsx'
import Calculator from './components/Calculator.jsx'
import NearbyBoba from './components/NearbyBoba.jsx'
import StickyNotes from './components/StickyNotes.jsx'
import Terminal from './components/Terminal.jsx'
import AmbiencePlayer from './components/AmbiencePlayer.jsx'
import RecipeBook from './components/RecipeBook.jsx'
import UnitConverter from './components/UnitConverter.jsx'
import CommandPalette from './components/CommandPalette.jsx'
import SettingsPage from './components/SettingsPage.jsx'
import FloatingApp from './components/FloatingApp.jsx'
import LoginScreen from './components/LoginScreen.jsx'
import LoadingSpinner from './components/LoadingSpinner.jsx'
import soundManager from './utils/soundManager.js'
import { useInstallPrompt } from './utils/useInstallPrompt.js'
import { useDarkMode } from './utils/useDarkMode.js'
import { useSettings } from './utils/useSettings.js'
import { useWindowManager } from './utils/useWindowManager.js'
import { detectDevice } from './utils/device.js'
import { recordVisit, migrateStatsOnRename } from './utils/stats.js'

const WINDOW_STATES = {
  NORMAL: 'normal',
  MAXIMIZED: 'maximized',
  MINIMIZED: 'minimized',
  CLOSED: 'closed',
}

const USER_STORAGE_KEY = 'bobaos_user'

const FLOATING_APPS = [
  { id: 'terminal', title: 'BobaShell', icon: TerminalSquare, width: 340, height: 400 },
  { id: 'notes', title: 'Boba Notes', icon: StickyNote, width: 320, height: 360 },
  { id: 'ambience', title: 'Café Ambience', icon: Music, width: 280, height: 320 },
  { id: 'recipes', title: 'Recipe Book', icon: BookOpen, width: 300, height: 380 },
  { id: 'converter', title: 'Unit Converter', icon: Ruler, width: 300, height: 320 },
]

function greeting(name) {
  const hour = new Date().getHours()
  const part = hour < 12 ? 'morning' : hour < 17 ? 'afternoon' : 'evening'
  return `Good ${part}, ${name} 🧋`
}

function scrollToWidget(id) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

/** Carries a per-user localStorage-backed dataset over to a new key on rename. */
function migrateUserKey(prefix, oldUser, newUser) {
  if (!oldUser || !newUser || oldUser.name === newUser.name) return
  try {
    const oldKey = `${prefix}_${oldUser.name}`
    const newKey = `${prefix}_${newUser.name}`
    const raw = window.localStorage.getItem(oldKey)
    if (raw) {
      window.localStorage.setItem(newKey, raw)
      window.localStorage.removeItem(oldKey)
    }
  } catch (e) {
    // ignore
  }
}

export default function App() {
  // BobaOS boots to the desktop, not straight into the app — matches how
  // a real OS behaves, and means the floating apps are reachable even if
  // you never open the main window at all.
  const [windowState, setWindowState] = useState(WINDOW_STATES.CLOSED)
  const [booting, setBooting] = useState(true)
  const [user, setUser] = useState(null)
  const [userLoaded, setUserLoaded] = useState(false)
  const [installBannerForceOpen, setInstallBannerForceOpen] = useState(false)
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [view, setView] = useState('dashboard') // 'dashboard' | 'settings'
  const installState = useInstallPrompt()
  const { mode, isDark, setMode, toggle: toggleTheme } = useDarkMode()
  const { settings, setVolume, setMuted, toggleWidget, resetWidgets } = useSettings()
  const winMgr = useWindowManager()

  // CPU/GPU/RAM readings are measured in-browser (see HardwareMonitor.jsx)
  // and aren't meaningful/reliable on iPadOS/iOS, so that card is skipped
  // there entirely rather than showing misleading numbers.
  const [hideHardwareMonitor] = useState(() => {
    const { deviceType } = detectDevice()
    return deviceType === 'iPad' || deviceType === 'iPhone'
  })
  const [isMac] = useState(() => /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent))

  const muted = settings.muted

  // Load saved username on first mount.
  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(USER_STORAGE_KEY)
      if (saved) setUser(JSON.parse(saved))
    } catch (e) {
      // ignore malformed storage
    }
    setUserLoaded(true)
  }, [])

  useEffect(() => {
    const t = setTimeout(() => setBooting(false), 1300)
    return () => clearTimeout(t)
  }, [])

  useEffect(() => {
    soundManager.setMuted(muted)
  }, [muted])

  useEffect(() => {
    soundManager.setVolume(settings.volume)
  }, [settings.volume])

  // One loyalty-card visit/streak update per session, once we know who's signed in.
  useEffect(() => {
    if (user) recordVisit(user)
  }, [user])

  // Global Cmd/Ctrl+K shortcut for the command palette.
  useEffect(() => {
    const onKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault()
        setPaletteOpen((o) => !o)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  const minimize = () => {
    soundManager.minimize()
    setWindowState(WINDOW_STATES.MINIMIZED)
  }

  const restore = () => {
    setWindowState(WINDOW_STATES.NORMAL)
  }

  const toggleMaximize = () => {
    soundManager.maximize()
    setWindowState((s) => (s === WINDOW_STATES.MAXIMIZED ? WINDOW_STATES.NORMAL : WINDOW_STATES.MAXIMIZED))
  }

  const close = () => {
    soundManager.close()
    setWindowState(WINDOW_STATES.CLOSED)
  }

  /** Opens the main BobaOS window from the desktop — auto-fills compact/phone screens. */
  const openBobaOS = () => {
    soundManager.maximize()
    setWindowState(window.innerWidth <= 900 || window.innerHeight <= 520 ? WINDOW_STATES.MAXIMIZED : WINDOW_STATES.NORMAL)
  }

  /** Desktop icon double-click/select-then-open handler. */
  const openDesktopApp = (id) => {
    if (id === 'bobaos') {
      openBobaOS()
    } else {
      winMgr.open(id)
    }
  }

  const handleLogin = (newUser) => {
    setUser(newUser)
    try {
      window.localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(newUser))
    } catch (e) {
      // storage may be unavailable (e.g. private browsing) — app still works
    }
  }

  const handleUpdateUser = (updates) => {
    setUser((prev) => {
      const next = { ...prev, ...updates }
      migrateStatsOnRename(prev, next)
      migrateUserKey('bobaos_notes', prev, next)
      migrateUserKey('bobaos_favrecipes', prev, next)
      try {
        window.localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(next))
      } catch (e) {
        // ignore
      }
      return next
    })
  }

  const handleSwitchUser = () => {
    soundManager.hover()
    setUser(null)
    setView('dashboard')
    try {
      window.localStorage.removeItem(USER_STORAGE_KEY)
    } catch (e) {
      // ignore
    }
  }

  const handleInstallClick = async () => {
    if (installState.canInstall) {
      await installState.promptInstall()
    } else {
      // No native prompt available (iOS Safari, or an unsupported desktop
      // browser) — surface the banner with the right instructions instead.
      setInstallBannerForceOpen(true)
    }
  }

  const toggleSettingsView = () => setView((v) => (v === 'settings' ? 'dashboard' : 'settings'))
  const openSettingsView = () => setView('settings')

  const maximized = windowState === WINDOW_STATES.MAXIMIZED
  const minimized = windowState === WINDOW_STATES.MINIMIZED
  const closed = windowState === WINDOW_STATES.CLOSED

  const appLabel = (id, name) => {
    const w = winMgr.windows[id]
    if (!w.open) return `Open ${name}`
    if (w.minimized) return `Restore ${name}`
    return `Minimize ${name}`
  }

  const commandActions = useMemo(() => {
    const actions = [
      {
        id: 'settings',
        label: view === 'settings' ? 'Back to dashboard' : 'Open Settings',
        icon: SettingsIcon,
        onRun: toggleSettingsView,
      },
      {
        id: 'theme',
        label: isDark ? 'Switch to Day Brew (light mode)' : 'Switch to Night Brew (dark mode)',
        icon: isDark ? Sun : Moon,
        keywords: ['dark', 'light', 'theme', 'night', 'day'],
        onRun: toggleTheme,
      },
      {
        id: 'mute',
        label: muted ? 'Unmute sound' : 'Mute sound',
        icon: muted ? Volume2 : VolumeX,
        keywords: ['sound', 'audio', 'mute'],
        onRun: () => setMuted(!muted),
      },
      closed
        ? { id: 'open-bobaos', label: 'Open BobaOS', icon: LayoutGrid, onRun: openBobaOS }
        : { id: 'minimize', label: 'Minimize BobaOS', icon: Minus, onRun: minimize },
    ]

    if (!closed) {
      actions.push(
        {
          id: 'maximize',
          label: maximized ? 'Restore window' : 'Maximize window',
          icon: Maximize2,
          onRun: toggleMaximize,
        },
        {
          id: 'close',
          label: 'Close the shop',
          icon: X,
          keywords: ['quit', 'exit'],
          onRun: close,
        }
      )
    }

    actions.push(
      {
        id: 'switch-user',
        label: 'Switch user',
        icon: UserRound,
        keywords: ['logout', 'log out', 'profile'],
        onRun: handleSwitchUser,
      },
      {
        id: 'install',
        label: installState.installed ? 'BobaOS is already installed' : 'Install BobaOS',
        icon: Download,
        keywords: ['pwa', 'app', 'home screen'],
        onRun: installState.installed ? () => {} : handleInstallClick,
      }
    )

    FLOATING_APPS.forEach(({ id, title, icon }) => {
      actions.push({
        id: `app-${id}`,
        label: appLabel(id, title),
        icon,
        keywords: [id],
        onRun: () => winMgr.handleDockClick(id),
      })
    })

    if (!closed && view === 'dashboard') {
      const jumps = [
        { key: 'weather', id: 'jump-weather', label: 'Jump to Boba Weather', icon: CloudSun },
        { key: 'clock', id: 'jump-clock', label: 'Jump to Café Timer', icon: ClockIcon },
        {
          key: 'hardware',
          id: 'jump-hardware',
          label: 'Jump to Boba Tank Levels',
          icon: Gauge,
          keywords: ['cpu', 'gpu', 'ram'],
          visible: !hideHardwareMonitor,
        },
        { key: 'device', id: 'jump-device', label: 'Jump to About This Café', icon: Monitor },
        { key: 'timer', id: 'jump-timer', label: 'Jump to Brew Timer', icon: Timer },
        { key: 'punchcard', id: 'jump-punchcard', label: 'Jump to Boba Punch Card', icon: Trophy },
        { key: 'calc', id: 'jump-calc', label: 'Jump to Boba Calc', icon: CalculatorIcon, keywords: ['calculator', 'math'] },
        { key: 'nearby', id: 'jump-nearby', label: 'Jump to Nearby Boba & Bites', icon: MapPin, keywords: ['map', 'restaurants', 'food'] },
        { key: 'arcade', id: 'jump-arcade', label: 'Jump to Mini Arcade', icon: Gamepad2, keywords: ['games', 'play'] },
      ]
      jumps
        .filter((j) => settings.widgets[j.key] && j.visible !== false)
        .forEach((j) => actions.push({ ...j, onRun: () => scrollToWidget(j.id) }))
    }

    return actions
  }, [isDark, muted, maximized, closed, installState.installed, hideHardwareMonitor, view, settings.widgets, winMgr.windows]) // eslint-disable-line react-hooks/exhaustive-deps

  const showBoot = booting || !userLoaded

  return (
    <div className="safe-area relative h-[100dvh] w-screen overflow-hidden flex items-center justify-center">
      {/* ambient background blobs */}
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-taro/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-16 h-80 w-80 rounded-full bg-matcha/30 blur-3xl" />
      <div className="pointer-events-none absolute top-1/3 right-1/4 h-40 w-40 rounded-full bg-blush/40 blur-3xl" />

      <AnimatePresence mode="wait">
        {showBoot ? (
          <motion.div
            key="boot"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-4"
          >
            <LoadingSpinner size={56} label="Steeping BobaOS…" />
          </motion.div>
        ) : closed ? (
          <Desktop key="desktop" onOpenApp={openDesktopApp} />
        ) : (
          <motion.div
            key="window"
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{
              opacity: minimized ? 0 : 1,
              scale: minimized ? 0.4 : 1,
              y: minimized ? 420 : 0,
              width: maximized ? '100%' : 960,
              height: maximized ? '100%' : 640,
            }}
            transition={{ type: 'spring', stiffness: 220, damping: 26 }}
            style={{ pointerEvents: minimized ? 'none' : 'auto' }}
            className="flex flex-col rounded-2xl overflow-hidden shadow-soft glow-border max-w-full max-h-full"
          >
            <TitleBar
              onMinimize={minimize}
              onMaximize={toggleMaximize}
              onClose={close}
              maximized={maximized}
              user={user}
              onSwitchUser={handleSwitchUser}
              installState={installState}
              onInstallClick={handleInstallClick}
              onOpenSettings={toggleSettingsView}
              settingsOpen={view === 'settings'}
            />

            {view === 'dashboard' && user && (
              <InstallPrompt
                {...installState}
                forceOpen={installBannerForceOpen}
                onForceOpenHandled={() => setInstallBannerForceOpen(false)}
              />
            )}

            <div className="flex-1 overflow-y-auto overscroll-contain bg-gradient-to-br from-cream via-milk/40 to-cream px-4 sm:px-6 py-5 sm:py-6">
              {!user ? (
                <div className="h-full w-full flex items-center justify-center">
                  <AnimatePresence mode="wait">
                    <LoginScreen key="login" onSubmit={handleLogin} />
                  </AnimatePresence>
                </div>
              ) : view === 'settings' ? (
                <SettingsPage
                  user={user}
                  onUpdateUser={handleUpdateUser}
                  onSwitchUser={handleSwitchUser}
                  onBack={() => setView('dashboard')}
                  mode={mode}
                  setMode={setMode}
                  muted={muted}
                  onToggleMute={() => setMuted(!muted)}
                  volume={settings.volume}
                  setVolume={setVolume}
                  widgets={settings.widgets}
                  onToggleWidget={toggleWidget}
                  onResetWidgets={resetWidgets}
                  hideHardwareMonitor={hideHardwareMonitor}
                />
              ) : (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <p className="font-display text-sm text-pearl/70">{greeting(user.name)}</p>
                    <button
                      onClick={() => setPaletteOpen(true)}
                      className="hidden sm:flex items-center gap-1.5 text-[11px] text-pearl/40 hover:text-pearl/70 transition-colors touch-manipulation"
                    >
                      Quick actions
                      <kbd className="px-1.5 py-0.5 rounded bg-white/40 font-mono text-[10px]">
                        {isMac ? '⌘K' : 'Ctrl K'}
                      </kbd>
                    </button>
                  </div>

                  <div
                    className={`grid grid-cols-1 sm:grid-cols-2 ${
                      hideHardwareMonitor ? 'xl:grid-cols-3' : 'xl:grid-cols-4'
                    } gap-4 sm:gap-5`}
                  >
                    {settings.widgets.weather && (
                      <div id="widget-weather" className="h-60"><WeatherWidget /></div>
                    )}
                    {settings.widgets.clock && (
                      <div id="widget-clock" className="h-60"><ClockWidget /></div>
                    )}
                    {!hideHardwareMonitor && settings.widgets.hardware && (
                      <div id="widget-hardware" className="h-60"><HardwareMonitor /></div>
                    )}
                    {settings.widgets.device && (
                      <div id="widget-device" className="h-60"><DeviceInfo /></div>
                    )}
                  </div>

                  {(settings.widgets.timer || settings.widgets.punchcard || settings.widgets.calc) && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 sm:gap-5 mt-4 sm:mt-5">
                      {settings.widgets.timer && (
                        <div id="widget-timer" className="h-80"><BrewTimer /></div>
                      )}
                      {settings.widgets.punchcard && (
                        <div id="widget-punchcard" className="h-80"><PunchCard user={user} /></div>
                      )}
                      {settings.widgets.calc && (
                        <div id="widget-calc" className="h-80"><Calculator /></div>
                      )}
                    </div>
                  )}

                  {settings.widgets.nearby && (
                    <div id="widget-nearby" className="h-80 mt-4 sm:mt-5">
                      <NearbyBoba />
                    </div>
                  )}

                  {settings.widgets.arcade && (
                    <div id="widget-arcade" className="mt-4 sm:mt-5">
                      <ArcadeSection user={user} />
                    </div>
                  )}

                  {!Object.values(settings.widgets).some(Boolean) && (
                    <div className="flex flex-col items-center justify-center gap-3 py-16 text-center">
                      <p className="text-sm text-pearl/50">Every widget is hidden right now.</p>
                      <button
                        onClick={() => {
                          soundManager.click()
                          resetWidgets()
                        }}
                        className="px-4 py-2 rounded-full bg-matcha text-white text-xs font-semibold shadow-soft hover:brightness-105 active:scale-95 transition touch-manipulation"
                      >
                        Show all widgets
                      </button>
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <Dock minimized={minimized} onRestore={restore} windows={winMgr.windows} onToggleApp={winMgr.handleDockClick} />

      <AnimatePresence>
        {FLOATING_APPS.map(({ id, title, icon, width, height }) => {
          const w = winMgr.windows[id]
          if (!w.open) return null
          return (
            <FloatingApp
              key={id}
              title={title}
              icon={icon}
              size={{ width, height }}
              position={{ x: w.x, y: w.y }}
              minimized={w.minimized}
              maximized={w.maximized}
              zIndex={70 + (w.z || 0)}
              onFocus={() => winMgr.focus(id)}
              onClose={() => winMgr.close(id)}
              onMinimize={() => winMgr.minimize(id)}
              onMaximize={() => winMgr.toggleMaximize(id)}
              onDragEnd={(pos) => winMgr.updatePosition(id, pos)}
            >
              {id === 'terminal' && (
                <Terminal
                  user={user}
                  setMode={setMode}
                  onUpdateUser={handleUpdateUser}
                  onOpenApp={winMgr.open}
                  onCloseApp={winMgr.close}
                  onOpenSettings={openSettingsView}
                  openApps={winMgr.windows}
                  setMuted={setMuted}
                  setVolume={setVolume}
                  onSwitchUser={handleSwitchUser}
                />
              )}
              {id === 'notes' && <StickyNotes user={user} />}
              {id === 'ambience' && <AmbiencePlayer />}
              {id === 'recipes' && <RecipeBook user={user} />}
              {id === 'converter' && <UnitConverter />}
            </FloatingApp>
          )
        })}
      </AnimatePresence>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} actions={commandActions} />
    </div>
  )
}
