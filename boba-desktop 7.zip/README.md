# BobaOS — Boba Tea Desktop Dashboard

A cozy, premium "desktop app"-style dashboard built with React, Vite, Tailwind CSS,
Framer Motion, Lucide icons, and a fully procedural Web Audio sound engine.

## Run it

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

To build a static production bundle:

```bash
npm run build
npm run preview
```

## What's inside

- **Window chrome** — `src/components/TitleBar.jsx` + `src/App.jsx` drive a
  Mac-style traffic-light window with real minimize / maximize / close state,
  animated with Framer Motion. Minimizing tucks the window into a boba-themed
  dock at the bottom (`src/components/Dock.jsx`).
- **A real macOS-style desktop** (`src/components/Desktop.jsx`) — BobaOS
  boots to this, not straight into the app, the way an actual OS boots to
  a desktop rather than an open window. It's not a placeholder screen: a
  translucent top menu bar (BobaOS branding + a live clock, macOS-style),
  and desktop icons in the classic macOS position (a column on the right)
  for every app — including BobaOS itself. Click an icon once to select
  it, click again (or double-click) to open, matching real Mac desktop
  behavior rather than a single flat tap-to-open grid. Closing the main
  BobaOS window returns you here rather than to a dead end.
- **Sound engine** — `src/utils/soundManager.js` synthesizes every click,
  hover, minimize (two sequential pearl pops), maximize, and the descending
  "sad pop" close sound directly with the Web Audio API — no audio files.
- **Weather** — `src/components/WeatherWidget.jsx` calls the free, key-free
  Open-Meteo API using the browser's geolocation (falls back to a default
  city if permission is denied), and layers boba-themed copy on top of the
  real temperature/condition.
- **Clock** — `src/components/ClockWidget.jsx` is a live analog "café timer"
  face plus a digital readout and mini week strip.
- **Hardware monitor** — `src/components/HardwareMonitor.jsx` shows CPU /
  GPU / RAM as liquid-filling "boba tanks," but backed by genuinely
  measured browser signals rather than random numbers: real logical core
  count (`navigator.hardwareConcurrency`), a live main-thread
  responsiveness reading (frame-timing jank), live measured FPS, real GPU
  renderer name (via WebGL, where the browser allows it), and this tab's
  actual JS heap usage (`performance.memory`, Chrome/Edge) or approximate
  device memory tier where that's unavailable. Browsers deliberately don't
  expose true system-wide utilization for privacy reasons, so this card is
  the closest a web page can honestly get — and it's hidden entirely on
  iPad/iPhone, where these signals aren't reliable.
- **Mini arcade** — `src/components/ArcadeSection.jsx` tabs between two
  playable games:
  - **Catch the Boba** (`games/CatchBobaGame.jsx`) — steer a cup with the
    mouse or arrow keys to catch falling pearls before time runs out.
  - **Tea Merge** (`games/TeaMerge2048.jsx`) — a 2048 clone where tea
    flavors (Water → Milk Tea → Taro → Matcha → … → Legendary Boba) merge
    as you slide tiles with the arrow keys or swipes.

- **Username system** — `src/components/LoginScreen.jsx` greets first-time
  visitors, asks for a name and a boba-cup color, and saves it to
  `localStorage`. Returning visitors skip straight to the dashboard with a
  time-of-day greeting ("Good afternoon, Alex 🧋"). The avatar chip in the
  title bar (`ProfileMenu.jsx`) offers "Switch user" to log out and hand the
  device to someone else.
- **"About This Café" device panel** — `src/components/DeviceInfo.jsx` +
  `src/utils/device.js` detect and display what you're actually using it on
  (iPad / iPhone / Android / desktop), OS, browser, touch vs. mouse input,
  screen size, pixel density, and orientation — live-updating on resize or
  rotation.
- **Dark mode ("Night Brew")** — a Sun/Moon toggle in the title bar
  (`src/utils/useDarkMode.js`) flips the whole app between a light "Day
  Brew" and a dark roast palette, remembers your choice in `localStorage`,
  respects the OS's `prefers-color-scheme` on first visit, and applies
  before first paint (an inline script in `index.html`) so there's no flash
  of the wrong theme on load. Implemented via CSS custom properties, not
  per-component overrides, so it's consistent everywhere.
- **Command palette** — press **⌘K** / **Ctrl+K** (or the "Quick actions"
  hint next to your greeting) for a searchable list of actions:
  `src/components/CommandPalette.jsx`. Toggle theme/sound, minimize/
  maximize/close, switch user, install the app, or jump straight to any
  widget. Arrow keys to navigate, Enter to run, Esc to close.
- **Brew Timer** — `src/components/BrewTimer.jsx`, a pomodoro/steep-timer
  with Quick/Focus/Deep presets, a progress bar, a completion chime, and
  (with permission) a real browser notification when time's up — handy
  for actually brewing tea or just focusing on something.
- **Boba Punch Card** — `src/components/PunchCard.jsx` +
  `src/utils/stats.js`, a loyalty-card-style widget tied to your signed-in
  username: visit streak (stamps), total visits, total pearls caught, and
  your best scores from both mini-games — all persisted in `localStorage`
  per username and updating live as you play.
- **Boba Calc** — `src/components/Calculator.jsx`, a themed calculator
  with full keyboard support (digits, `+ - * /`, Enter/`=`, Backspace,
  Escape to clear) that's careful not to steal keystrokes from other text
  inputs elsewhere on the page.
- **Nearby Boba & Bites** — `src/components/NearbyBoba.jsx`, a real map +
  list of nearby cafés, tea shops, and restaurants using your device's
  location. Built entirely on free, key-free services so there's nothing
  to configure:
  - Place data from **OpenStreetMap's Overpass API** (cafés, tea shops,
    anything tagged `cuisine=bubble_tea`, and restaurants within ~1.5km).
  - The interactive map itself is **Leaflet** rendering standard OSM
    tiles, with emoji markers (🧋 for boba-tagged spots, 🍽️ for everything
    else) — no API key, no billing account, nothing to sign up for.
  - Each result links out to Google Maps for turn-by-turn directions
    (`https://www.google.com/maps/search/?api=1&query=lat,lon` — this is
    a keyless universal Maps link, not the Google Maps API).
  - Heads up: OpenStreetMap's public tile server asks that high-traffic
    production apps use a paid or self-hosted tile provider instead (e.g.
    MapTiler, Stadia Maps, Mapbox) rather than hammering the free one —
    fine as-is for personal use or a low-traffic deploy, worth swapping
    the tile URL in `NearbyBoba.jsx` if this takes off.
- **Settings** — `src/components/SettingsPage.jsx`, opened from the gear
  icon in the title bar, replaces the dashboard with a proper full settings
  screen rather than a cramped popover:
  - **Profile** — rename yourself or change your cup color anytime (not
    just at first login); punch-card stats automatically migrate if you
    rename.
  - **Appearance** — Day Brew / Night Brew / **System**, where System
    tracks the OS theme live instead of just reading it once.
  - **Sound** — a real volume slider (not just mute), backed by
    `soundManager.setVolume`.
  - **Dashboard widgets** — show/hide any widget individually; the
    dashboard grid, and the command palette's "jump to" list, both respect
    this live.
  - **Data & account** — reset your Punch Card stats, switch users, and a
    plain-language note on what's stored locally.
  - **About** — credits for every external service used (Open-Meteo,
    OpenStreetMap/Overpass, Leaflet, Google Fonts).
- **Standalone floating apps** — BobaShell, Boba Notes, Café Ambience,
  Recipe Book, and Unit Converter aren't dashboard widgets — they're real
  independent floating windows (`src/components/FloatingApp.jsx`) with
  their own Mac-style traffic lights (close / minimize / maximize),
  draggable from the title bar, with proper click-to-front stacking order.
  They live entirely outside the main BobaOS window's own state, and their
  open/closed/minimized/maximized state and screen position all persist
  across reloads (`src/utils/useWindowManager.js`, backed by
  `localStorage`) — leave five of them open, close the tab, come back
  later, and they're exactly how you left them.
  - **Minimize** hides a window but keeps it running — Café Ambience, for
    instance, keeps playing while minimized, the way a real background app
    would.
  - **Maximize** expands a window to fill most of the screen; the traffic
    light toggles between maximize and restore.
  - Dragging only starts from the title bar, not from anywhere inside the
    window — so buttons, text inputs, and the terminal's command line all
    get normal, uninterrupted clicks and typing.
  - **Launch them from the taskbar** — the Dock at the bottom of the
    screen (`src/components/Dock.jsx`) has an icon for each; the indicator
    dot is solid when open, dim when minimized. Clicking a running app's
    dock icon minimizes it; clicking again restores it — standard taskbar
    behavior.
  - **Or from the command palette** — ⌘K / Ctrl+K, with the label
    reflecting current state ("Open X" / "Minimize X" / "Restore X").
  - **They keep working even if you close the main BobaOS window** — the
    desktop screen you land on when BobaOS is closed (see below) has an
    icon for every one of them, so they keep working independent of the
    main app's window state, the way a real OS's taskbar apps don't quit
    just because you closed one window.
  - **BobaShell** (`Terminal.jsx`) is a genuinely useful little shell, not
    just a novelty — it can actually drive the app:
    `help`, `whoami`, `date`/`time`, `echo <text>`, `sysinfo` (real
    detected device info), `neofetch`, `theme <day|night|system>`,
    `color <cup color>`, `rename <name>`, `volume <0-100>`, `mute`/`unmute`,
    `open <notes|ambience|recipes|converter|settings>`,
    `close <notes|ambience|recipes|converter>`, `ls`,
    `cat <file>` (a tiny fake filesystem), `calc <expression>` (safe —
    only digits/operators are ever evaluated), `stats` (your Punch Card
    numbers), `apps` (what's open/minimized/closed), `joke`, `fortune`,
    `history`, `uptime`, `clear`, and `logout`/`exit`. Arrow-key command
    history included.
  - **Boba Notes** (`StickyNotes.jsx`) — quick sticky notes, saved per
    username.
  - **Café Ambience** (`AmbiencePlayer.jsx`) — three fully generative,
    procedurally synthesized background loops (Rainy Window, Lo-Fi Focus,
    Matcha Chill) built on the same Web Audio engine as the sound
    effects — no audio files, sharing the Settings volume/mute controls
    rather than having a separate hidden volume.
  - **Recipe Book** (`RecipeBook.jsx`) — a small browsable list of tea
    recipes with ingredients, favoritable (★) and persisted per username.
  - **Unit Converter** (`UnitConverter.jsx`) — length, weight, volume, and
    temperature conversion.
- **Boba Memory** — a third arcade game (flip-card matching) alongside
  Catch the Boba and Tea Merge, all sharing the same Mini Arcade panel
  (this one's a dashboard widget, not a floating app, since it belongs
  with the other games).

## Progressive Web App (PWA)

BobaOS installs like a real app — on desktop, Android, and iPad/iPhone.

- Powered by `vite-plugin-pwa` (already in `package.json` — installs with
  `npm install`, no extra setup).
- **Web app manifest** (`vite.config.js`) with the generated boba-cup icon
  set in `public/icons/` (192px, 512px, and a maskable variant for
  Android's adaptive icon shapes), `display: "standalone"` so it opens
  without browser chrome, and matching theme/background colors.
- **Offline support** via a Workbox-generated service worker that
  precaches the app shell, so it opens even with no connection. The
  weather widget uses a network-first strategy so it stays live when
  online but won't hard-fail offline; Google Fonts are cached long-term.
- **In-app install**: a persistent **Install** button lives in the title
  bar at all times (`src/components/TitleBar.jsx`, driven by
  `src/utils/useInstallPrompt.js`). On Chrome/Edge/desktop/Android it
  triggers the real browser install dialog directly; on iPad/iPhone Safari
  (which has no install API) or an unsupported browser, it opens a small
  banner with the right instructions instead. Once installed, the button
  turns into an "Installed" badge. There's also an auto-surfacing dismissible
  banner (`src/components/InstallPrompt.jsx`) the first time installing
  becomes available, for people who miss the button.
- Test installability locally with `npm run build && npm run preview`
  (service workers generally don't run reliably from `npm run dev` in
  most browsers, though `devOptions.enabled: true` is set so it will
  attempt to in dev too).

## Deploying to GitHub Pages

A workflow is already set up at `.github/workflows/deploy.yml`, and
`vite.config.js` uses a relative `base: './'` (and a relative PWA
`start_url`/`scope`) so the build works correctly from a project subpath
like `https://<you>.github.io/<repo>/` — no need to edit anything for your
specific repo name.

1. Push this project to a GitHub repository (see below if you haven't yet).
2. In the repo, go to **Settings → Pages**, and under "Build and deployment
   → Source", choose **GitHub Actions**.
3. Push to `main` (or run the workflow manually from the **Actions** tab).
   It builds the app and deploys `dist/` automatically.
4. Your site will be live at `https://<your-username>.github.io/<repo-name>/`
   — GitHub shows the exact URL on the Pages settings screen and in the
   workflow run summary once it succeeds.

Pushing to GitHub, if you haven't already:

```bash
cd boba-desktop
git init
git add .
git commit -m "Initial commit: BobaOS dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

Since GitHub Pages serves over HTTPS, the install button and offline
support both work correctly once it's live there.

## iPad & phone support

- The window auto-fills the screen on compact viewports (width ≤ 900px or
  height ≤ 520px) instead of trying to render the 960×640 desktop window.
- Both mini-games render at a fixed internal resolution but are scaled down
  responsively (via a measured-container + CSS transform) so they fit
  phone widths without ever overflowing or requiring horizontal scrolling.
- Traffic-light window controls and other tap targets are sized for touch,
  `touch-action: manipulation` avoids double-tap zoom, `100dvh` handles
  mobile Safari's shifting viewport, and `env(safe-area-inset-*)` keeps
  content clear of notches / home indicators.
- Add it to the iPad/iPhone home screen (Share → Add to Home Screen) for a
  standalone, fullscreen "app" feel — the meta tags for that are already set.

## Notes

- Browsers require a user gesture before audio can play — sound kicks in
  as soon as you click anything (this is standard Web Audio behavior, not
  a bug).
- The weather widget will ask for location permission; deny it and it
  quietly falls back to a default city. Nearby Boba & Bites also needs
  location access — if it's denied there's no city fallback (it wouldn't
  make sense to show "nearby" places for a random city), just a retry
  button once you enable it.
- The username is stored only in the browser's own `localStorage` — there's
  no backend, so it's local to that device/browser. Punch Card stats are
  keyed per-username the same way.
- Dark mode re-themes the app's chrome (backgrounds, text, glass panels,
  borders); the illustrative graphics (the boba cup logo, the analog clock
  face, the tank liquid colors) intentionally stay the same bright colors
  in both themes, the way app icons usually don't get "dark mode" treatment.
- `prefers-reduced-motion` is respected globally.
- Floating app windows remember their position across reloads and are
  clamped so a drag can never leave the title bar unreachable off-screen.

## Fixed along the way

A few real bugs, in case you're wondering why some of this looks
deliberate rather than incidental:

- **Floating windows were unclickable.** Framer Motion's `drag` was
  originally applied to the entire window, so every click — including on
  buttons and text inputs — was first intercepted as a potential drag
  gesture. Fixed by scoping drag to the title bar only
  (`useDragControls` + `dragListener={false}`), the documented pattern
  for a drag handle.
- **Mute didn't actually mute Café Ambience.** `soundManager.setMuted()`
  only blocked new one-shot SFX from being scheduled; it never touched
  the shared gain node, so anything routed straight through it (the
  ambience engine) kept playing regardless. Fixed by having mute/volume
  both drive the actual master gain value.
- **Refreshing Nearby Boba & Bites could break the map.** Its Leaflet
  instance is bound to a DOM node that unmounts every time results are
  re-fetched (while status leaves `'ready'`); without tearing the old map
  down first, a refresh would try to control a map attached to an
  already-removed element. Fixed by disposing the previous instance at
  the start of every reload.
- **Renaming yourself silently lost your notes and favorite recipes.**
  Punch Card stats were already migrated to the new username on rename;
  notes and recipe favorites (both keyed per-username too) weren't. Now
  all three migrate together.
- **Typing into any text field was broken on mobile.** Every real text
  input in the app (BobaShell's command line, Boba Notes, the command
  palette, Unit Converter, both name fields) was rendered under 16px.
  Combined with the `user-scalable=no` viewport meta tag (there for the
  native-app pinch-zoom-free feel), that's the textbook iOS Safari bug
  where focusing a small-font input fights the browser's auto-zoom-to-
  legibility behavior and breaks typing. Every real input is now at least
  16px; the app's small-text aesthetic is preserved everywhere else,
  since that only ever applied to display text, never to what you type
  into.
- A profile-menu backdrop and the Dock shared the exact same `z-40`,
  which could make one swallow clicks meant for the other depending on
  DOM stacking order. Given an explicit lower value so there's no tie.

## Also added this round

- **Auto-maximize on phones.** Dragging a small floating window around a
  phone screen is awkward, so opening one on a narrow viewport now starts
  it maximized instead — still fully restorable via its own traffic light.
- **Double-click/double-tap a title bar** to maximize or restore, the
  usual OS shortcut, in addition to the green traffic light.
- **Haptic feedback** on supported devices (Android Chrome, mainly —
  iOS Safari doesn't expose the vibration API) — a subtle tap alongside
  clicks, minimize, maximize, close, and success/error sounds. Silently
  does nothing where unsupported.
- Floating windows' internal scroll areas (terminal history, notes,
  recipes) now use `overscroll-behavior: contain` so scrolling inside a
  small window doesn't rubber-band/chain into the page behind it.

## Latest round: desktop redesign + more fixes

- **Unit Converter was actually broken.** `UnitSelect` (the from/to
  dropdowns) was declared *inside* `UnitConverter`'s component body, a
  classic React footgun: React saw it as a brand-new component type on
  every render and fully unmounted/remounted the `<select>` elements —
  including on every keystroke in the number field. Fixed by hoisting it
  to module scope.
- **The root container's padding was silently dead.** `.safe-area` (for
  notch/home-indicator insets) and Tailwind's `p-3 sm:p-6` (general
  breathing room) were both setting the same CSS padding properties on
  the same element; since `.safe-area` was defined later in the
  stylesheet, it always won the cascade — collapsing the intended padding
  to ~0 on every non-notched device. Fixed by having `.safe-area` combine
  both (`max(env(safe-area-inset-*), base-padding)`) instead of only one
  ever applying.
- **Rebuilt the "closed" screen as a real macOS-style desktop**
  (`Desktop.jsx`) with a menu bar and right-column app icons for BobaOS
  and all five floating apps, replacing the old plain "shop is closed"
  message + 3-shortcut row.
- **BobaOS now boots to the desktop, not into the app.** `windowState`
  defaults to closed; opening BobaOS is now something you do (double-click
  its desktop icon, or ⌘K → "Open BobaOS"), the way an actual OS works.
  The boot spinner moved up to gate the whole app rather than living
  inside a window that might not even open this session.
