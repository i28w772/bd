/** @type {import('tailwindcss').Config} */

// Wires a Tailwind color to a CSS custom property (defined in index.css for
// both :root and .dark), so every existing bg-cream / text-pearl / etc.
// class automatically responds to dark mode with no per-component changes,
// and the `/opacity` modifier syntax (e.g. text-pearl/70) keeps working.
function themed(varName) {
  return ({ opacityValue }) =>
    opacityValue === undefined ? `rgb(var(${varName}))` : `rgb(var(${varName}) / ${opacityValue})`
}

export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        cream: themed('--color-cream'),
        milk: themed('--color-milk'),
        'milk-dark': themed('--color-milk-dark'),
        matcha: {
          DEFAULT: themed('--color-matcha'),
          light: themed('--color-matcha-light'),
          dark: themed('--color-matcha-dark'),
        },
        taro: {
          DEFAULT: themed('--color-taro'),
          light: themed('--color-taro-light'),
          dark: themed('--color-taro-dark'),
        },
        pearl: {
          DEFAULT: themed('--color-pearl'),
          light: themed('--color-pearl-light'),
        },
        blush: themed('--color-blush'),
      },
      fontFamily: {
        display: ['"Fredoka"', 'sans-serif'],
        body: ['"Quicksand"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 24px rgba(179, 156, 208, 0.35)',
        'glow-matcha': '0 0 24px rgba(140, 167, 121, 0.35)',
        soft: '0 8px 30px rgba(74, 51, 36, 0.12)',
      },
      backdropBlur: {
        xs: '2px',
      },
      keyframes: {
        rise: {
          '0%': { transform: 'translateY(0)', opacity: '0.9' },
          '100%': { transform: 'translateY(-140px)', opacity: '0' },
        },
        wobble: {
          '0%, 100%': { transform: 'rotate(-2deg)' },
          '50%': { transform: 'rotate(2deg)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      animation: {
        rise: 'rise 3.2s ease-in infinite',
        wobble: 'wobble 2.4s ease-in-out infinite',
        shimmer: 'shimmer 2.5s linear infinite',
      },
    },
  },
  plugins: [],
}
